<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Data Transaksi</title>
    <!-- Bootstrap CSS -->
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
</head>

<body>
    <div class="container">
        <h1 class="my-4">Tambah Data Transaksi</h1>
        <!-- Form for adding transaction data -->
        <form id="transaksiForm" method="POST" action="proses_input_transaksi.php">
            <div id="barangList">
                <div class="barang-item form-group">
                    <label for="nama_barang">Nama Barang:</label>
                    <input type="text" class="form-control nama_barang" name="nama_barang[]" required>
                    <div class="suggestions list-group"></div>

                    <label for="jumlah_stok">Jumlah Stok Tersedia:</label>
                    <input type="text" class="form-control jumlah_stok" name="jumlah_stok[]" readonly required>

                    <label for="jumlah">Jumlah:</label>
                    <input type="number" class="form-control jumlah" name="jumlah[]" required>

                    <label for="harga">Harga:</label>
                    <input type="text" class="form-control harga" name="harga[]" readonly required>

                    <label for="total">Total:</label>
                    <input type="text" class="form-control total" name="total[]" readonly required>
                </div>
            </div>
            <button type="button" class="btn btn-success my-3" id="addBarangBtn">Tambah Barang</button>
            <div class="form-group">
                <label for="grand_total">Grand Total:</label>
                <input type="text" class="form-control" id="grand_total" name="grand_total" readonly required>
            </div>
            <div class="form-group">
                <label for="bayar">Bayar:</label>
                <input type="text" class="form-control" id="bayar" name="bayar" required>
            </div>
            <div class="form-group">
                <label for="kembalian">Kembalian:</label>
                <input type="text" class="form-control" id="kembalian" name="kembalian" readonly required>
            </div>
            <button type="submit" class="btn btn-primary">Tambah Transaksi</button>
            <a href="javascript:history.back()" class="btn btn-secondary">Kembali</a>
        </form>
    </div>

    <!-- Bootstrap JS dan Popper.js -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.3/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const addBarangBtn = document.getElementById('addBarangBtn');
            const barangList = document.getElementById('barangList');
            
            const barangTemplate = `
                <div class="barang-item form-group">
                    <label for="nama_barang">Nama Barang:</label>
                    <input type="text" class="form-control nama_barang" name="nama_barang[]" required>
                    <div class="suggestions list-group"></div>

                    <label for="jumlah_stok">Jumlah Stok Tersedia:</label>
                    <input type="text" class="form-control jumlah_stok" name="jumlah_stok[]" readonly required>

                    <label for="jumlah">Jumlah:</label>
                    <input type="number" class="form-control jumlah" name="jumlah[]" required>

                    <label for="harga">Harga:</label>
                    <input type="text" class="form-control harga" name="harga[]" readonly required>

                    <label for="total">Total:</label>
                    <input type="text" class="form-control total" name="total[]" readonly required>
                </div>`;

            addBarangBtn.addEventListener('click', function() {
                barangList.insertAdjacentHTML('beforeend', barangTemplate);
            });

            document.getElementById('transaksiForm').addEventListener('input', function(e) {
                if (e.target.classList.contains('nama_barang')) {
                    var namaBarang = e.target.value;
                    if (namaBarang.length > 2) {
                        var xhr = new XMLHttpRequest();
                        xhr.open('POST', 'get_stok_by_name.php', true);
                        xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
                        xhr.onreadystatechange = function() {
                            if (xhr.readyState === 4 && xhr.status === 200) {
                                var stokList = JSON.parse(xhr.responseText);
                                var suggestions = e.target.nextElementSibling;
                                suggestions.innerHTML = '';
                                stokList.forEach(function(stok) {
                                    var suggestion = document.createElement('a');
                                    suggestion.className = 'list-group-item list-group-item-action';
                                    suggestion.textContent = stok.NAMA_BARANG;
                                    suggestion.addEventListener('click', function() {
                                        e.target.value = stok.NAMA_BARANG;
                                        e.target.parentNode.querySelector('.jumlah_stok').value = stok.JUMLAH;
                                        e.target.parentNode.querySelector('.harga').value = formatRupiah(stok.HARGA.toString());
                                        suggestions.innerHTML = '';
                                        hitungTotal();
                                    });
                                    suggestions.appendChild(suggestion);
                                });
                            }
                        };
                        xhr.send('nama_barang=' + encodeURIComponent(namaBarang));
                    }
                } else if (e.target.classList.contains('jumlah') || e.target.classList.contains('harga')) {
                    hitungTotal();
                }
            });

            document.getElementById('bayar').addEventListener('input', function() {
                var bayar = this.value.replace(/[^,\d]/g, '');
                this.value = formatRupiah(bayar);
                hitungKembalian();
            });

            function hitungTotal() {
                let grandTotal = 0;
                const barangItems = document.querySelectorAll('.barang-item');
                barangItems.forEach(function(item) {
                    const jumlah = item.querySelector('.jumlah').value;
                    const harga = item.querySelector('.harga').value.replace(/[^,\d]/g, '');
                    const total = jumlah * harga;
                    item.querySelector('.total').value = formatRupiah(total.toString());
                    grandTotal += total;
                });
                document.getElementById('grand_total').value = formatRupiah(grandTotal.toString());
                hitungKembalian();
            }

            function hitungKembalian() {
                const grandTotal = document.getElementById('grand_total').value.replace(/[^,\d]/g, '');
                const bayar = document.getElementById('bayar').value.replace(/[^,\d]/g, '');
                let kembalian = bayar - grandTotal;
                if (kembalian < 0) kembalian = 0;
                document.getElementById('kembalian').value = formatRupiah(kembalian.toString());
            }

            function formatRupiah(angka, prefix) {
                var number_string = angka.replace(/[^,\d]/g, '').toString(),
                    split = number_string.split(','),
                    sisa = split[0].length % 3,
                    rupiah = split[0].substr(0, sisa),
                    ribuan = split[0].substr(sisa).match(/\d{3}/gi);

                if (ribuan) {
                    separator = sisa ? '.' : '';
                    rupiah += separator + ribuan.join('.');
                }

                rupiah = split[1] != undefined ? rupiah + ',' + split[1] : rupiah;
                return prefix == undefined ? rupiah : (rupiah ? 'Rp. ' + rupiah : '');
            }
        });
    </script>
</body>

</html>
