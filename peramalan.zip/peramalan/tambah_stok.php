<?php
session_start();
require_once "koneksi.php"; // File ini berisi kode untuk koneksi ke database

if (!isset($_SESSION['NAMA']) || !isset($_SESSION['role'])) {
    header("Location: index.php");
    exit();
}


// Menghitung jumlah barang yang ada di database
$queryCount = "SELECT COUNT(*) as jumlah FROM stok";
$resultCount = $connection->query($queryCount);
$rowCount = $resultCount->fetch_assoc();
$jumlahBarang = $rowCount['jumlah'];
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Data Stok</title>
    <!-- Bootstrap CSS -->
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
</head>

<body>
    <div class="container">
        <h1 class="my-4">Tambah Data Stok</h1>
        <!-- Form for adding stock data -->
        <form method="POST" action="proses_input_stok.php" onsubmit="removeRupiahPrefix()">
            <div class="form-group">
                <label for="ID_STOK">ID Stok:</label>
                <input type="text" class="form-control" id="ID_STOK" name="ID_STOK" readonly required>
            </div>
            <div class="form-group">
                <label for="nama_barang">Nama Barang:</label>
                <input type="text" class="form-control" id="nama_barang" name="nama_barang" required oninput="generateIDStok()">
            </div>
            <div class="form-group">
                <label for="jumlah">Jumlah:</label>
                <input type="number" class="form-control" id="jumlah" name="jumlah" required>
            </div>
            <div class="form-group">
                <label for="harga">Harga:</label>
                <input type="text" class="form-control" id="harga" name="harga" required oninput="formatRupiah(this)">
            </div>
            <button type="submit" class="btn btn-primary">Tambah Stok</button>
            <a href="javascript:history.back()" class="btn btn-secondary">Kembali</a>
        </form>
    </div>

    <!-- Bootstrap JS dan Popper.js -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.3/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    
    <script>
        function formatRupiah(element) {
            let value = element.value.replace(/[^,\d]/g, '').toString();
            let split = value.split(',');
            let sisa = split[0].length % 3;
            let rupiah = split[0].substr(0, sisa);
            let ribuan = split[0].substr(sisa).match(/\d{3}/gi);
        
            if (ribuan) {
                let separator = sisa ? '.' : '';
                rupiah += separator + ribuan.join('.');
            }
        
            rupiah = split[1] !== undefined ? rupiah + ',' + split[1] : rupiah;
            element.value = 'Rp. ' + rupiah;
        }

        function generateIDStok() {
            let namaBarang = document.getElementById('nama_barang').value;
            if (namaBarang.length > 0) {
                let prefix = namaBarang.charAt(0).toUpperCase(); // Huruf awal dari nama barang
                let nomorUrut = <?php echo $jumlahBarang + 1; ?>; // Nomor urut berdasarkan jumlah barang
                let idStok = prefix + ('000' + nomorUrut).slice(-4); // Padding dengan 0 di depan jika perlu
                document.getElementById('ID_STOK').value = idStok;
            } else {
                document.getElementById('ID_STOK').value = '';
            }
        }

        function removeRupiahPrefix() {
            let hargaField = document.getElementById('harga');
            hargaField.value = hargaField.value.replace(/[^0-9]/g, '');
        }
    </script>
</body>

</html>
