<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Data Penjualan</title>
    <!-- Bootstrap CSS -->
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <h1 class="mb-4">Tambah Data Penjualan</h1>
        <form action="proses_input_data_penjualan.php" method="post">
            <div class="form-group">
                <label for="NAMA_BARANG">Nama Barang:</label>
                <input type="text" class="form-control" id="NAMA_BARANG" name="NAMA_BARANG" required>
            </div>
            <div class="form-group">
                <label for="BULAN">Bulan:</label>
                <input type="number" class="form-control" id="BULAN" name="BULAN" min="1" max="12" required>
            </div>
            <div class="form-group">
                <label for="TAHUN">Tahun:</label>
                <input type="number" class="form-control" id="TAHUN" name="TAHUN" required>
            </div>
            <div class="form-group">
                <label for="JUMLAH_TERJUAL">Jumlah Terjual:</label>
                <input type="number" class="form-control" id="JUMLAH_TERJUAL" name="JUMLAH_TERJUAL" required>
            </div>
            <button type="submit" class="btn btn-primary">Tambah</button>
            <a href="javascript:history.back()" class="btn btn-secondary">Kembali</a>
        </form>
    </div>
    
    <!-- Bootstrap JS, Popper.js, and jQuery -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
