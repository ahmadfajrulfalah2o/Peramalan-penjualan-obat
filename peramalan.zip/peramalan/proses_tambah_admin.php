<?php
session_start();
require_once "koneksi.php"; // File ini berisi kode untuk koneksi ke database

if (!isset($_SESSION['NAMA']) || !isset($_SESSION['role']) || $_SESSION['role'] != 'owner') {
    header("Location: index.php");
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nama = $_POST['nama'];
    $password = $_POST['password'];
    $role = $_POST['role'];

    // Generate ID_ADMIN
    $queryCount = "SELECT COUNT(*) AS total FROM admin";
    $result = $connection->query($queryCount);
    $row = $result->fetch_assoc();
    $total = $row['total'];
    $id_admin = "ADM" . str_pad($total + 1, 4, '0', STR_PAD_LEFT); // Generates ID like ADM0001, ADM0002, ...

    // Insert data into admin table
    $queryInsert = "INSERT INTO admin (ID_ADMIN, NAMA, PASSWORD, role) VALUES (?, ?, ?, ?)";
    $stmt = $connection->prepare($queryInsert);
    $stmt->bind_param('ssss', $id_admin, $nama, $password, $role);

    if ($stmt->execute()) {
        echo "<div class='container mt-5'><div class='alert alert-success'>Pegawai baru berhasil ditambahkan!</div></div>";
    } else {
        echo "<div class='container mt-5'><div class='alert alert-danger'>Error: " . $stmt->error . "</div></div>";
    }

    $stmt->close();
    $connection->close();
} else {
    echo "<div class='container mt-5'><div class='alert alert-danger'>Invalid request.</div></div>";
    exit();
}
?>
