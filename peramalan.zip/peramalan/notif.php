<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Transaksi</title>
    <style>
        /* Tambahkan CSS untuk notifikasi mengambang */
        .floating-notification {
            display: none;
            position: fixed;
            top: 20px;
            right: 20px;
            background-color: #4CAF50;
            color: white;
            padding: 15px;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            z-index: 1000;
        }
    </style>
</head>
<body>
    <!-- Notifikasi mengambang -->
    <div id="notification" class="floating-notification">Transaksi berhasil!</div>

    <!-- Form transaksi dan konten lainnya di sini -->

    <!-- Tambahkan JavaScript untuk menampilkan notifikasi -->
    <script>
        function showNotification() {
            var notification = document.getElementById('notification');
            notification.style.display = 'block';
            setTimeout(function() {
                notification.style.display = 'none';
            }, 3000);
        }

        <?php if (isset($transaksiBerhasil) && $transaksiBerhasil) { ?>
            showNotification();
        <?php } ?>
    </script>
</body>
</html>
