<?php
session_start();
session_unset(); // Menghapus semua variabel sesi
session_destroy(); // Mengakhiri sesi

header("Location: index.php"); // Alihkan ke halaman login atau halaman utama
exit();
?>
