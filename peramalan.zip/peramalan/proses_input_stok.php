<?php
session_start();
require_once "koneksi.php"; // File ini berisi kode untuk koneksi ke database

if (!isset($_SESSION['NAMA']) || !isset($_SESSION['role'])) {
    header("Location: index.php");
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id_stok = $_POST['ID_STOK'];
    $nama_barang = $_POST['nama_barang'];
    $jumlah = $_POST['jumlah'];
    $harga = $_POST['harga'];

    // Ensure harga is numeric
    if (!is_numeric($harga)) {
        $harga = floatval(preg_replace("/[^0-9]/", "", $harga));
    }

    $query = "INSERT INTO stok (ID_STOK, NAMA_BARANG, JUMLAH, HARGA) VALUES ('$id_stok', '$nama_barang', '$jumlah', '$harga')";

    if ($connection->query($query) === TRUE) {
        header("Location: stok.php");
        exit();
    } else {
        echo "Error: " . $query . "<br>" . $connection->error;
    }
}

$connection->close();
?>
