<?php
$host = 'localhost';
$username = 'root';
$password = '';
$dbname = 'apotek';
$connection = new mysqli($host, $username, $password, $dbname);

// Periksa koneksi
if ($connection->connect_error) {
    die("Koneksi gagal: " . $connection->connect_error);
}

// Mengambil data hasil peramalan
$sql = "SELECT p.BULAN, p.TAHUN, h.NAMA_BARANG, dp.JUMLAH_TERJUAL, p.HASIL_RAMAL, p.ERROR, p.ERROR2
        FROM peramalan p
        JOIN hasil h ON p.ID_PERAMALAN = h.ID_PERAMALAN
        JOIN data_penjualan dp ON h.NAMA_BARANG = dp.NAMA_BARANG AND p.BULAN = dp.BULAN AND p.TAHUN = dp.TAHUN
        WHERE p.TAHUN = 2023 OR (p.TAHUN = 2024 AND p.BULAN = 1)
        ORDER BY p.TAHUN, p.BULAN";
$result = $connection->query($sql);

echo "<table border='1'>
<tr>
<th>BULAN</th>
<th>TAHUN</th>
<th>NAMA BARANG</th>
<th>JUMLAH TERJUAL</th>
<th>HASIL RAMAL</th>
<th>ERROR</th>
<th>ERROR2</th>
<th>RMSE</th>
</tr>";

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        echo "<tr>";
        echo "<td>" . $row['BULAN'] . "</td>";
        echo "<td>" . $row['TAHUN'] . "</td>";
        echo "<td>" . $row['NAMA_BARANG'] . "</td>";
        echo "<td>" . $row['JUMLAH_TERJUAL'] . "</td>";
        echo "<td>" . $row['HASIL_RAMAL'] . "</td>";
        echo "<td>" . $row['ERROR'] . "</td>";
        echo "<td>" . $row['ERROR2'] . "</td>";
        echo "<td>" . $rmse . "</td>";
        echo "</tr>";
    }
} else {
    echo "0 results";
}
echo "</table>";

$connection->close();
?>
