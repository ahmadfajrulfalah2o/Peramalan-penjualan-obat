<?php
session_start();
require_once "koneksi.php"; // File ini berisi kode untuk koneksi ke database

// Mengecek apakah user telah login
if (!isset($_SESSION['NAMA']) || !isset($_SESSION['role'])) {
    header("Location: index.php");
    exit();
}

// Mengecek apakah form telah disubmit
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['id_peramalan'])) {
        $idPeramalan = $_POST['id_peramalan'];

        // Menghapus data peramalan
        $queryDeleteHasil = "DELETE FROM hasil WHERE ID_PERAMALAN = ?";
        $stmtDeleteHasil = $connection->prepare($queryDeleteHasil);
        $stmtDeleteHasil->bind_param("s", $idPeramalan);
        $stmtDeleteHasil->execute();

        $queryDeletePeramalan = "DELETE FROM peramalan WHERE ID_PERAMALAN = ?";
        $stmtDeletePeramalan = $connection->prepare($queryDeletePeramalan);
        $stmtDeletePeramalan->bind_param("s", $idPeramalan);
        $stmtDeletePeramalan->execute();
    } elseif (isset($_POST['nama_barang'])) {
        $namaBarang = $_POST['nama_barang'];

        // Menghapus semua data berdasarkan nama barang
        $queryDeleteHasilAll = "DELETE FROM hasil WHERE ID_PERAMALAN IN (SELECT ID_PERAMALAN FROM peramalan WHERE NAMA_BARANG = ?)";
        $stmtDeleteHasilAll = $connection->prepare($queryDeleteHasilAll);
        $stmtDeleteHasilAll->bind_param("s", $namaBarang);
        $stmtDeleteHasilAll->execute();

        $queryDeletePeramalanAll = "DELETE FROM peramalan WHERE NAMA_BARANG = ?";
        $stmtDeletePeramalanAll = $connection->prepare($queryDeletePeramalanAll);
        $stmtDeletePeramalanAll->bind_param("s", $namaBarang);
        $stmtDeletePeramalanAll->execute();
    }

    header("Location: hasil_prediksi.php");
    exit();
}
?>
