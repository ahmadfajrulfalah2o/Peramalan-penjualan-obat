-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 11, 2024 at 02:44 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `apotek`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `ID_ADMIN` varchar(30) NOT NULL,
  `NAMA` varchar(30) DEFAULT NULL,
  `PASSWORD` varchar(25) DEFAULT NULL,
  `role` enum('owner','pegawai') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`ID_ADMIN`, `NAMA`, `PASSWORD`, `role`) VALUES
('01', 'owner1', '11111', 'owner'),
('02', 'pegawai', '11111', 'pegawai'),
('ADM0003', 'budi', '11111', 'pegawai');

-- --------------------------------------------------------

--
-- Table structure for table `data_penjualan`
--

CREATE TABLE `data_penjualan` (
  `NOMER` int(100) NOT NULL,
  `ID_TRANSAKSI` varchar(35) DEFAULT NULL,
  `ID_STOK` varchar(20) DEFAULT NULL,
  `ID_PERAMALAN` varchar(40) DEFAULT NULL,
  `NAMA_BARANG` varchar(40) DEFAULT NULL,
  `BULAN` int(20) DEFAULT NULL,
  `TAHUN` int(20) DEFAULT NULL,
  `JUMLAH_TERJUAL` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `data_penjualan`
--

INSERT INTO `data_penjualan` (`NOMER`, `ID_TRANSAKSI`, `ID_STOK`, `ID_PERAMALAN`, `NAMA_BARANG`, `BULAN`, `TAHUN`, `JUMLAH_TERJUAL`) VALUES
(1, NULL, NULL, NULL, 'Hufagrip', 7, 2022, '15'),
(2, NULL, NULL, NULL, 'Hufagrip', 8, 2022, '12'),
(3, NULL, NULL, NULL, 'Hufagrip', 9, 2022, '16'),
(4, NULL, NULL, NULL, 'Hufagrip', 10, 2022, '15'),
(5, NULL, NULL, NULL, 'Hufagrip', 11, 2022, '11'),
(6, NULL, NULL, NULL, 'Hufagrip', 12, 2022, '14'),
(7, NULL, NULL, NULL, 'Hufagrip', 1, 2023, '10'),
(8, NULL, NULL, NULL, 'Hufagrip', 2, 2023, '19'),
(9, NULL, NULL, NULL, 'Hufagrip', 3, 2023, '13'),
(10, NULL, NULL, NULL, 'Hufagrip', 4, 2023, '14'),
(11, NULL, NULL, NULL, 'Hufagrip', 5, 2023, '18'),
(12, NULL, NULL, NULL, 'Hufagrip', 6, 2023, '20'),
(13, NULL, NULL, NULL, 'Hufagrip', 7, 2023, '14'),
(14, NULL, NULL, NULL, 'Hufagrip', 8, 2023, '13'),
(15, NULL, NULL, NULL, 'Hufagrip', 9, 2023, '12'),
(16, NULL, NULL, NULL, 'Hufagrip', 10, 2023, '14'),
(17, NULL, NULL, NULL, 'Hufagrip', 11, 2023, '17'),
(18, NULL, NULL, NULL, 'Hufagrip', 12, 2023, '26'),
(19, NULL, NULL, NULL, 'Hufagrip', 1, 2024, '26'),
(20, NULL, NULL, NULL, 'Hufagrip', 2, 2024, '25'),
(21, NULL, NULL, NULL, 'Hufagrip', 3, 2024, '20'),
(22, NULL, NULL, NULL, 'Hufagrip', 4, 2024, '21'),
(23, NULL, NULL, NULL, 'Hufagrip', 5, 2024, '24'),
(24, NULL, NULL, NULL, 'Hufagrip', 6, 2024, '18'),
(25, NULL, NULL, NULL, 'Paracetamol', 7, 2022, '15'),
(26, NULL, NULL, NULL, 'Paracetamol', 8, 2022, '18'),
(27, NULL, NULL, NULL, 'Paracetamol', 9, 2022, '14'),
(28, NULL, NULL, NULL, 'Paracetamol', 10, 2022, '16'),
(29, NULL, NULL, NULL, 'Paracetamol', 11, 2022, '20'),
(30, NULL, NULL, NULL, 'Paracetamol', 12, 2022, '21'),
(31, NULL, NULL, NULL, 'Paracetamol', 1, 2023, '29'),
(32, NULL, NULL, NULL, 'Paracetamol', 2, 2023, '24'),
(33, NULL, NULL, NULL, 'Paracetamol', 3, 2023, '15'),
(34, NULL, NULL, NULL, 'Paracetamol', 4, 2023, '18'),
(35, NULL, NULL, NULL, 'Paracetamol', 5, 2023, '18'),
(36, NULL, NULL, NULL, 'Paracetamol', 6, 2023, '17'),
(37, NULL, NULL, NULL, 'Paracetamol', 7, 2023, '10'),
(38, NULL, NULL, NULL, 'Paracetamol', 8, 2023, '8'),
(39, NULL, NULL, NULL, 'Paracetamol', 9, 2023, '8'),
(40, NULL, NULL, NULL, 'Paracetamol', 10, 2023, '12'),
(41, NULL, NULL, NULL, 'Paracetamol', 11, 2023, '15'),
(42, NULL, NULL, NULL, 'Paracetamol', 12, 2023, '7'),
(43, NULL, NULL, NULL, 'Paracetamol', 1, 2024, '4'),
(44, NULL, NULL, NULL, 'Paracetamol', 2, 2024, '9'),
(45, NULL, NULL, NULL, 'Paracetamol', 3, 2024, '8'),
(46, NULL, NULL, NULL, 'Paracetamol', 4, 2024, '11'),
(47, NULL, NULL, NULL, 'Paracetamol', 5, 2024, '14'),
(48, NULL, NULL, NULL, 'Paracetamol', 6, 2024, '12'),
(49, NULL, NULL, NULL, 'Promag Tablet', 7, 2022, '20'),
(50, NULL, NULL, NULL, 'Promag Tablet', 8, 2022, '22'),
(51, NULL, NULL, NULL, 'Promag Tablet', 9, 2022, '19'),
(52, NULL, NULL, NULL, 'Promag Tablet', 10, 2022, '14'),
(53, NULL, NULL, NULL, 'Promag Tablet', 11, 2022, '14'),
(54, NULL, NULL, NULL, 'Promag Tablet', 12, 2022, '15'),
(55, NULL, NULL, NULL, 'Promag Tablet', 1, 2023, '13'),
(56, NULL, NULL, NULL, 'Promag Tablet', 2, 2023, '16'),
(57, NULL, NULL, NULL, 'Promag Tablet', 3, 2023, '14'),
(58, NULL, NULL, NULL, 'Promag Tablet', 4, 2023, '20'),
(59, NULL, NULL, NULL, 'Promag Tablet', 5, 2023, '20'),
(60, NULL, NULL, NULL, 'Promag Tablet', 6, 2023, '24'),
(61, NULL, NULL, NULL, 'Promag Tablet', 7, 2023, '18'),
(62, NULL, NULL, NULL, 'Promag Tablet', 8, 2023, '25'),
(63, NULL, NULL, NULL, 'Promag Tablet', 9, 2023, '23'),
(64, NULL, NULL, NULL, 'Promag Tablet', 10, 2023, '22'),
(65, NULL, NULL, NULL, 'Promag Tablet', 11, 2023, '18'),
(66, NULL, NULL, NULL, 'Promag Tablet', 12, 2023, '15'),
(67, NULL, NULL, NULL, 'Promag Tablet', 1, 2024, '14'),
(68, NULL, NULL, NULL, 'Promag Tablet', 2, 2024, '17'),
(69, NULL, NULL, NULL, 'Promag Tablet', 3, 2024, '16'),
(70, NULL, NULL, NULL, 'Promag Tablet', 4, 2024, '20'),
(71, NULL, NULL, NULL, 'Promag Tablet', 5, 2024, '22'),
(72, NULL, NULL, NULL, 'Promag Tablet', 6, 2024, '17'),
(73, NULL, NULL, NULL, 'Captopril', 7, 2022, '6'),
(74, NULL, NULL, NULL, 'Captopril', 8, 2022, '7'),
(75, NULL, NULL, NULL, 'Captopril', 9, 2022, '9'),
(76, NULL, NULL, NULL, 'Captopril', 10, 2022, '6'),
(77, NULL, NULL, NULL, 'Captopril', 11, 2022, '10'),
(78, NULL, NULL, NULL, 'Captopril', 12, 2022, '8'),
(79, NULL, NULL, NULL, 'Captopril', 1, 2023, '5'),
(80, NULL, NULL, NULL, 'Captopril', 2, 2023, '6'),
(81, NULL, NULL, NULL, 'Captopril', 3, 2023, '8'),
(82, NULL, NULL, NULL, 'Captopril', 4, 2023, '7'),
(83, NULL, NULL, NULL, 'Captopril', 5, 2023, '5'),
(84, NULL, NULL, NULL, 'Captopril', 6, 2023, '9'),
(85, NULL, NULL, NULL, 'Captopril', 7, 2023, '10'),
(86, NULL, NULL, NULL, 'Captopril', 8, 2023, '6'),
(87, NULL, NULL, NULL, 'Captopril', 9, 2023, '7'),
(88, NULL, NULL, NULL, 'Captopril', 10, 2023, '13'),
(89, NULL, NULL, NULL, 'Captopril', 11, 2023, '12'),
(90, NULL, NULL, NULL, 'Captopril', 12, 2023, '4'),
(91, NULL, NULL, NULL, 'Captopril', 1, 2024, '8'),
(92, NULL, NULL, NULL, 'Captopril', 2, 2024, '14'),
(93, NULL, NULL, NULL, 'Captopril', 3, 2024, '9'),
(94, NULL, NULL, NULL, 'Captopril', 4, 2024, '7'),
(95, NULL, NULL, NULL, 'Captopril', 5, 2024, '7'),
(96, NULL, NULL, NULL, 'Captopril', 6, 2024, '5'),
(97, NULL, NULL, NULL, 'Ampicilin Trihydrate', 7, 2022, '22'),
(98, NULL, NULL, NULL, 'Ampicilin Trihydrate', 8, 2022, '25'),
(99, NULL, NULL, NULL, 'Ampicilin Trihydrate', 9, 2022, '17'),
(100, NULL, NULL, NULL, 'Ampicilin Trihydrate', 10, 2022, '14'),
(101, NULL, NULL, NULL, 'Ampicilin Trihydrate', 11, 2022, '20'),
(102, NULL, NULL, NULL, 'Ampicilin Trihydrate', 12, 2022, '20'),
(103, NULL, NULL, NULL, 'Ampicilin Trihydrate', 1, 2023, '18'),
(104, NULL, NULL, NULL, 'Ampicilin Trihydrate', 2, 2023, '21'),
(105, NULL, NULL, NULL, 'Ampicilin Trihydrate', 3, 2023, '17'),
(106, NULL, NULL, NULL, 'Ampicilin Trihydrate', 4, 2023, '20'),
(107, NULL, NULL, NULL, 'Ampicilin Trihydrate', 5, 2023, '26'),
(108, NULL, NULL, NULL, 'Ampicilin Trihydrate', 6, 2023, '27'),
(109, NULL, NULL, NULL, 'Ampicilin Trihydrate', 7, 2023, '30'),
(110, NULL, NULL, NULL, 'Ampicilin Trihydrate', 8, 2023, '33'),
(111, NULL, NULL, NULL, 'Ampicilin Trihydrate', 9, 2023, '35'),
(112, NULL, NULL, NULL, 'Ampicilin Trihydrate', 10, 2023, '25'),
(113, NULL, NULL, NULL, 'Ampicilin Trihydrate', 11, 2023, '26'),
(114, NULL, NULL, NULL, 'Ampicilin Trihydrate', 12, 2023, '24'),
(115, NULL, NULL, NULL, 'Ampicilin Trihydrate', 1, 2024, '21'),
(116, NULL, NULL, NULL, 'Ampicilin Trihydrate', 2, 2024, '15'),
(117, NULL, NULL, NULL, 'Ampicilin Trihydrate', 3, 2024, '12'),
(118, NULL, NULL, NULL, 'Ampicilin Trihydrate', 4, 2024, '21'),
(119, NULL, NULL, NULL, 'Ampicilin Trihydrate', 5, 2024, '15'),
(120, NULL, NULL, NULL, 'Ampicilin Trihydrate', 6, 2024, '16'),
(121, NULL, NULL, NULL, 'freshcare', 7, 2024, '1'),
(122, NULL, NULL, NULL, 'Betadine', 7, 2024, '2'),
(123, NULL, NULL, NULL, 'komix', 7, 2024, '101');

-- --------------------------------------------------------

--
-- Table structure for table `hasil`
--

CREATE TABLE `hasil` (
  `NO` int(100) NOT NULL,
  `ID_PERAMALAN` varchar(40) DEFAULT NULL,
  `NAMA_BARANG` varchar(40) DEFAULT NULL,
  `BULAN` int(11) DEFAULT NULL,
  `TAHUN` int(11) DEFAULT NULL,
  `PERAMALAN` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `hasil`
--

INSERT INTO `hasil` (`NO`, `ID_PERAMALAN`, `NAMA_BARANG`, `BULAN`, `TAHUN`, `PERAMALAN`) VALUES
(4413, 'P0051', 'Paracetamol', 7, 2022, NULL),
(4414, 'P0052', 'Paracetamol', 8, 2022, NULL),
(4415, 'P0053', 'Paracetamol', 9, 2022, NULL),
(4416, 'P0054', 'Paracetamol', 10, 2022, NULL),
(4417, 'P0055', 'Paracetamol', 11, 2022, NULL),
(4418, 'P0056', 'Paracetamol', 12, 2022, NULL),
(4419, 'P0057', 'Paracetamol', 1, 2023, NULL),
(4420, 'P0058', 'Paracetamol', 2, 2023, NULL),
(4421, 'P0059', 'Paracetamol', 3, 2023, NULL),
(4422, 'P0060', 'Paracetamol', 4, 2023, NULL),
(4423, 'P0061', 'Paracetamol', 5, 2023, NULL),
(4424, 'P0062', 'Paracetamol', 6, 2023, NULL),
(4425, 'P0063', 'Paracetamol', 7, 2023, NULL),
(4426, 'P0064', 'Paracetamol', 8, 2023, NULL),
(4427, 'P0065', 'Paracetamol', 9, 2023, NULL),
(4428, 'P0066', 'Paracetamol', 10, 2023, NULL),
(4429, 'P0067', 'Paracetamol', 11, 2023, NULL),
(4430, 'P0068', 'Paracetamol', 12, 2023, NULL),
(4431, 'P0069', 'Paracetamol', 1, 2024, NULL),
(4432, 'P0070', 'Paracetamol', 2, 2024, NULL),
(4433, 'P0071', 'Paracetamol', 3, 2024, NULL),
(4434, 'P0072', 'Paracetamol', 4, 2024, NULL),
(4435, 'P0073', 'Paracetamol', 5, 2024, NULL),
(4436, 'P0074', 'Paracetamol', 6, 2024, NULL),
(4437, 'P0075', 'Paracetamol', 7, 2024, NULL),
(4438, 'P0076', 'Promag Tablet', 7, 2022, NULL),
(4439, 'P0077', 'Promag Tablet', 8, 2022, NULL),
(4440, 'P0078', 'Promag Tablet', 9, 2022, NULL),
(4441, 'P0079', 'Promag Tablet', 10, 2022, NULL),
(4442, 'P0080', 'Promag Tablet', 11, 2022, NULL),
(4443, 'P0081', 'Promag Tablet', 12, 2022, NULL),
(4444, 'P0082', 'Promag Tablet', 1, 2023, NULL),
(4445, 'P0083', 'Promag Tablet', 2, 2023, NULL),
(4446, 'P0084', 'Promag Tablet', 3, 2023, NULL),
(4447, 'P0085', 'Promag Tablet', 4, 2023, NULL),
(4448, 'P0086', 'Promag Tablet', 5, 2023, NULL),
(4449, 'P0087', 'Promag Tablet', 6, 2023, NULL),
(4450, 'P0088', 'Promag Tablet', 7, 2023, NULL),
(4451, 'P0089', 'Promag Tablet', 8, 2023, NULL),
(4452, 'P0090', 'Promag Tablet', 9, 2023, NULL),
(4453, 'P0091', 'Promag Tablet', 10, 2023, NULL),
(4454, 'P0092', 'Promag Tablet', 11, 2023, NULL),
(4455, 'P0093', 'Promag Tablet', 12, 2023, NULL),
(4456, 'P0094', 'Promag Tablet', 1, 2024, NULL),
(4457, 'P0095', 'Promag Tablet', 2, 2024, NULL),
(4458, 'P0096', 'Promag Tablet', 3, 2024, NULL),
(4459, 'P0097', 'Promag Tablet', 4, 2024, NULL),
(4460, 'P0098', 'Promag Tablet', 5, 2024, NULL),
(4461, 'P0099', 'Promag Tablet', 6, 2024, NULL),
(4462, 'P0100', 'Promag Tablet', 7, 2024, NULL),
(4588, 'P0101', 'Hufagrip', 7, 2022, NULL),
(4589, 'P0102', 'Hufagrip', 8, 2022, NULL),
(4590, 'P0103', 'Hufagrip', 9, 2022, NULL),
(4591, 'P0104', 'Hufagrip', 10, 2022, NULL),
(4592, 'P0105', 'Hufagrip', 11, 2022, NULL),
(4593, 'P0106', 'Hufagrip', 12, 2022, NULL),
(4594, 'P0107', 'Hufagrip', 1, 2023, NULL),
(4595, 'P0108', 'Hufagrip', 2, 2023, NULL),
(4596, 'P0109', 'Hufagrip', 3, 2023, NULL),
(4597, 'P0110', 'Hufagrip', 4, 2023, NULL),
(4598, 'P0111', 'Hufagrip', 5, 2023, NULL),
(4599, 'P0112', 'Hufagrip', 6, 2023, NULL),
(4600, 'P0113', 'Hufagrip', 7, 2023, NULL),
(4601, 'P0114', 'Hufagrip', 8, 2023, NULL),
(4602, 'P0115', 'Hufagrip', 9, 2023, NULL),
(4603, 'P0116', 'Hufagrip', 10, 2023, NULL),
(4604, 'P0117', 'Hufagrip', 11, 2023, NULL),
(4605, 'P0118', 'Hufagrip', 12, 2023, NULL),
(4606, 'P0119', 'Hufagrip', 1, 2024, NULL),
(4607, 'P0120', 'Hufagrip', 2, 2024, NULL),
(4608, 'P0121', 'Hufagrip', 3, 2024, NULL),
(4609, 'P0122', 'Hufagrip', 4, 2024, NULL),
(4610, 'P0123', 'Hufagrip', 5, 2024, NULL),
(4611, 'P0124', 'Hufagrip', 6, 2024, NULL),
(4612, 'P0125', 'Hufagrip', 7, 2024, NULL),
(4613, 'P0126', 'Hufagrip', 7, 2022, NULL),
(4614, 'P0127', 'Hufagrip', 8, 2022, NULL),
(4615, 'P0128', 'Hufagrip', 9, 2022, NULL),
(4616, 'P0129', 'Hufagrip', 10, 2022, NULL),
(4617, 'P0130', 'Hufagrip', 11, 2022, NULL),
(4618, 'P0131', 'Hufagrip', 12, 2022, NULL),
(4619, 'P0132', 'Hufagrip', 1, 2023, NULL),
(4620, 'P0133', 'Hufagrip', 2, 2023, NULL),
(4621, 'P0134', 'Hufagrip', 3, 2023, NULL),
(4622, 'P0135', 'Hufagrip', 4, 2023, NULL),
(4623, 'P0136', 'Hufagrip', 5, 2023, NULL),
(4624, 'P0137', 'Hufagrip', 6, 2023, NULL),
(4625, 'P0138', 'Hufagrip', 7, 2023, NULL),
(4626, 'P0139', 'Hufagrip', 8, 2023, NULL),
(4627, 'P0140', 'Hufagrip', 9, 2023, NULL),
(4628, 'P0141', 'Hufagrip', 10, 2023, NULL),
(4629, 'P0142', 'Hufagrip', 11, 2023, NULL),
(4630, 'P0143', 'Hufagrip', 12, 2023, NULL),
(4631, 'P0144', 'Hufagrip', 1, 2024, NULL),
(4632, 'P0145', 'Hufagrip', 2, 2024, NULL),
(4633, 'P0146', 'Hufagrip', 3, 2024, NULL),
(4634, 'P0147', 'Hufagrip', 4, 2024, NULL),
(4635, 'P0148', 'Hufagrip', 5, 2024, NULL),
(4636, 'P0149', 'Hufagrip', 6, 2024, NULL),
(4637, 'P0150', 'Hufagrip', 7, 2024, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `peramalan`
--

CREATE TABLE `peramalan` (
  `ID_PERAMALAN` varchar(40) NOT NULL,
  `BULAN` int(20) DEFAULT NULL,
  `TAHUN` varchar(20) DEFAULT NULL,
  `HASIL_RAMAL` double DEFAULT NULL,
  `ERROR` double DEFAULT NULL,
  `ERROR2` double DEFAULT NULL,
  `PERIODE` int(11) DEFAULT NULL,
  `RMSE` double NOT NULL,
  `TOTAL_ERROR_KUADRAT` double DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `peramalan`
--

INSERT INTO `peramalan` (`ID_PERAMALAN`, `BULAN`, `TAHUN`, `HASIL_RAMAL`, `ERROR`, `ERROR2`, `PERIODE`, `RMSE`, `TOTAL_ERROR_KUADRAT`) VALUES
('P0051', 7, '2022', NULL, NULL, NULL, 2, 4.825359148197252, 512.25),
('P0052', 8, '2022', NULL, NULL, NULL, 2, 4.825359148197252, 512.25),
('P0053', 9, '2022', 16.5, -2.5, 6.25, 2, 4.825359148197252, 512.25),
('P0054', 10, '2022', 16, 0, 0, 2, 4.825359148197252, 512.25),
('P0055', 11, '2022', 15, 5, 25, 2, 4.825359148197252, 512.25),
('P0056', 12, '2022', 18, 3, 9, 2, 4.825359148197252, 512.25),
('P0057', 1, '2023', 20.5, 8.5, 72.25, 2, 4.825359148197252, 512.25),
('P0058', 2, '2023', 25, -1, 1, 2, 4.825359148197252, 512.25),
('P0059', 3, '2023', 26.5, -11.5, 132.25, 2, 4.825359148197252, 512.25),
('P0060', 4, '2023', 19.5, -1.5, 2.25, 2, 4.825359148197252, 512.25),
('P0061', 5, '2023', 16.5, 1.5, 2.25, 2, 4.825359148197252, 512.25),
('P0062', 6, '2023', 18, -1, 1, 2, 4.825359148197252, 512.25),
('P0063', 7, '2023', 17.5, -7.5, 56.25, 2, 4.825359148197252, 512.25),
('P0064', 8, '2023', 13.5, -5.5, 30.25, 2, 4.825359148197252, 512.25),
('P0065', 9, '2023', 9, -1, 1, 2, 4.825359148197252, 512.25),
('P0066', 10, '2023', 8, 4, 16, 2, 4.825359148197252, 512.25),
('P0067', 11, '2023', 10, 5, 25, 2, 4.825359148197252, 512.25),
('P0068', 12, '2023', 13.5, -6.5, 42.25, 2, 4.825359148197252, 512.25),
('P0069', 1, '2024', 11, -7, 49, 2, 4.825359148197252, 512.25),
('P0070', 2, '2024', 5.5, 3.5, 12.25, 2, 4.825359148197252, 512.25),
('P0071', 3, '2024', 6.5, 1.5, 2.25, 2, 4.825359148197252, 512.25),
('P0072', 4, '2024', 8.5, 2.5, 6.25, 2, 4.825359148197252, 512.25),
('P0073', 5, '2024', 9.5, 4.5, 20.25, 2, 4.825359148197252, 512.25),
('P0074', 6, '2024', 12.5, -0.5, 0.25, 2, 4.825359148197252, 512.25),
('P0075', 7, '2024', 13, NULL, NULL, 2, 4.825359148197252, 512.25),
('P0076', 7, '2022', NULL, NULL, NULL, 2, 3.374368627812266, 250.5),
('P0077', 8, '2022', NULL, NULL, NULL, 2, 3.374368627812266, 250.5),
('P0078', 9, '2022', 21, -2, 4, 2, 3.374368627812266, 250.5),
('P0079', 10, '2022', 20.5, -6.5, 42.25, 2, 3.374368627812266, 250.5),
('P0080', 11, '2022', 16.5, -2.5, 6.25, 2, 3.374368627812266, 250.5),
('P0081', 12, '2022', 14, 1, 1, 2, 3.374368627812266, 250.5),
('P0082', 1, '2023', 14.5, -1.5, 2.25, 2, 3.374368627812266, 250.5),
('P0083', 2, '2023', 14, 2, 4, 2, 3.374368627812266, 250.5),
('P0084', 3, '2023', 14.5, -0.5, 0.25, 2, 3.374368627812266, 250.5),
('P0085', 4, '2023', 15, 5, 25, 2, 3.374368627812266, 250.5),
('P0086', 5, '2023', 17, 3, 9, 2, 3.374368627812266, 250.5),
('P0087', 6, '2023', 20, 4, 16, 2, 3.374368627812266, 250.5),
('P0088', 7, '2023', 22, -4, 16, 2, 3.374368627812266, 250.5),
('P0089', 8, '2023', 21, 4, 16, 2, 3.374368627812266, 250.5),
('P0090', 9, '2023', 21.5, 1.5, 2.25, 2, 3.374368627812266, 250.5),
('P0091', 10, '2023', 24, -2, 4, 2, 3.374368627812266, 250.5),
('P0092', 11, '2023', 22.5, -4.5, 20.25, 2, 3.374368627812266, 250.5),
('P0093', 12, '2023', 20, -5, 25, 2, 3.374368627812266, 250.5),
('P0094', 1, '2024', 16.5, -2.5, 6.25, 2, 3.374368627812266, 250.5),
('P0095', 2, '2024', 14.5, 2.5, 6.25, 2, 3.374368627812266, 250.5),
('P0096', 3, '2024', 15.5, 0.5, 0.25, 2, 3.374368627812266, 250.5),
('P0097', 4, '2024', 16.5, 3.5, 12.25, 2, 3.374368627812266, 250.5),
('P0098', 5, '2024', 18, 4, 16, 2, 3.374368627812266, 250.5),
('P0099', 6, '2024', 21, -4, 16, 2, 3.374368627812266, 250.5),
('P0100', 7, '2024', 19.5, NULL, NULL, 2, 3.374368627812266, 250.5),
('P0101', 7, '2022', NULL, NULL, NULL, 2, 4.179223503344741, 384.25),
('P0102', 8, '2022', NULL, NULL, NULL, 2, 4.179223503344741, 384.25),
('P0103', 9, '2022', 13.5, 2.5, 6.25, 2, 4.179223503344741, 384.25),
('P0104', 10, '2022', 14, 1, 1, 2, 4.179223503344741, 384.25),
('P0105', 11, '2022', 15.5, -4.5, 20.25, 2, 4.179223503344741, 384.25),
('P0106', 12, '2022', 13, 1, 1, 2, 4.179223503344741, 384.25),
('P0107', 1, '2023', 12.5, -2.5, 6.25, 2, 4.179223503344741, 384.25),
('P0108', 2, '2023', 12, 7, 49, 2, 4.179223503344741, 384.25),
('P0109', 3, '2023', 14.5, -1.5, 2.25, 2, 4.179223503344741, 384.25),
('P0110', 4, '2023', 16, -2, 4, 2, 4.179223503344741, 384.25),
('P0111', 5, '2023', 13.5, 4.5, 20.25, 2, 4.179223503344741, 384.25),
('P0112', 6, '2023', 16, 4, 16, 2, 4.179223503344741, 384.25),
('P0113', 7, '2023', 19, -5, 25, 2, 4.179223503344741, 384.25),
('P0114', 8, '2023', 17, -4, 16, 2, 4.179223503344741, 384.25),
('P0115', 9, '2023', 13.5, -1.5, 2.25, 2, 4.179223503344741, 384.25),
('P0116', 10, '2023', 12.5, 1.5, 2.25, 2, 4.179223503344741, 384.25),
('P0117', 11, '2023', 13, 4, 16, 2, 4.179223503344741, 384.25),
('P0118', 12, '2023', 15.5, 10.5, 110.25, 2, 4.179223503344741, 384.25),
('P0119', 1, '2024', 21.5, 4.5, 20.25, 2, 4.179223503344741, 384.25),
('P0120', 2, '2024', 26, -1, 1, 2, 4.179223503344741, 384.25),
('P0121', 3, '2024', 25.5, -5.5, 30.25, 2, 4.179223503344741, 384.25),
('P0122', 4, '2024', 22.5, -1.5, 2.25, 2, 4.179223503344741, 384.25),
('P0123', 5, '2024', 20.5, 3.5, 12.25, 2, 4.179223503344741, 384.25),
('P0124', 6, '2024', 22.5, -4.5, 20.25, 2, 4.179223503344741, 384.25),
('P0125', 7, '2024', 21, NULL, NULL, 2, 4.179223503344741, 384.25),
('P0126', 7, '2022', NULL, NULL, NULL, 5, 4.777579215240156, 433.68000000000006),
('P0127', 8, '2022', NULL, NULL, NULL, 5, 4.777579215240156, 433.68000000000006),
('P0128', 9, '2022', NULL, NULL, NULL, 5, 4.777579215240156, 433.68000000000006),
('P0129', 10, '2022', NULL, NULL, NULL, 5, 4.777579215240156, 433.68000000000006),
('P0130', 11, '2022', NULL, NULL, NULL, 5, 4.777579215240156, 433.68000000000006),
('P0131', 12, '2022', 13.8, 0.1999999999999993, 0.039999999999999716, 5, 4.777579215240156, 433.68000000000006),
('P0132', 1, '2023', 13.6, -3.5999999999999996, 12.959999999999997, 5, 4.777579215240156, 433.68000000000006),
('P0133', 2, '2023', 13.2, 5.800000000000001, 33.64000000000001, 5, 4.777579215240156, 433.68000000000006),
('P0134', 3, '2023', 13.8, -0.8000000000000007, 0.6400000000000011, 5, 4.777579215240156, 433.68000000000006),
('P0135', 4, '2023', 13.4, 0.5999999999999996, 0.3599999999999996, 5, 4.777579215240156, 433.68000000000006),
('P0136', 5, '2023', 14, 4, 16, 5, 4.777579215240156, 433.68000000000006),
('P0137', 6, '2023', 14.8, 5.199999999999999, 27.039999999999992, 5, 4.777579215240156, 433.68000000000006),
('P0138', 7, '2023', 16.8, -2.8000000000000007, 7.840000000000004, 5, 4.777579215240156, 433.68000000000006),
('P0139', 8, '2023', 15.8, -2.8000000000000007, 7.840000000000004, 5, 4.777579215240156, 433.68000000000006),
('P0140', 9, '2023', 15.8, -3.8000000000000007, 14.440000000000005, 5, 4.777579215240156, 433.68000000000006),
('P0141', 10, '2023', 15.4, -1.4000000000000004, 1.960000000000001, 5, 4.777579215240156, 433.68000000000006),
('P0142', 11, '2023', 14.6, 2.4000000000000004, 5.760000000000002, 5, 4.777579215240156, 433.68000000000006),
('P0143', 12, '2023', 14, 12, 144, 5, 4.777579215240156, 433.68000000000006),
('P0144', 1, '2024', 16.4, 9.600000000000001, 92.16000000000003, 5, 4.777579215240156, 433.68000000000006),
('P0145', 2, '2024', 19, 6, 36, 5, 4.777579215240156, 433.68000000000006),
('P0146', 3, '2024', 21.6, -1.6000000000000014, 2.5600000000000045, 5, 4.777579215240156, 433.68000000000006),
('P0147', 4, '2024', 22.8, -1.8000000000000007, 3.2400000000000024, 5, 4.777579215240156, 433.68000000000006),
('P0148', 5, '2024', 23.6, 0.3999999999999986, 0.15999999999999887, 5, 4.777579215240156, 433.68000000000006),
('P0149', 6, '2024', 23.2, -5.199999999999999, 27.039999999999992, 5, 4.777579215240156, 433.68000000000006),
('P0150', 7, '2024', 21.6, NULL, NULL, 5, 4.777579215240156, 433.68000000000006);

-- --------------------------------------------------------

--
-- Table structure for table `stok`
--

CREATE TABLE `stok` (
  `ID_STOK` varchar(20) NOT NULL,
  `NAMA_BARANG` varchar(40) DEFAULT NULL,
  `JUMLAH` varchar(35) DEFAULT NULL,
  `HARGA` varchar(35) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `stok`
--

INSERT INTO `stok` (`ID_STOK`, `NAMA_BARANG`, `JUMLAH`, `HARGA`) VALUES
('A0005', 'Ampicilin Trihydrate', '99999', '6000'),
('B0006', 'Betadine', '993', '10000'),
('C0004', 'Captopril', '999999', '12000'),
('F0008', 'freshcare', '9996', '10000'),
('H0001', 'Hufagrip ', '999999', '26000'),
('I0007', 'insto', '9999', '20000'),
('K0009', 'komix', '898', '2000'),
('P0002', 'Paracetamol', '99999', '5500'),
('P0003', 'Promag Tablet', '9999999', '10000');

-- --------------------------------------------------------

--
-- Table structure for table `transaksi`
--

CREATE TABLE `transaksi` (
  `ID_TRANSAKSI` varchar(35) NOT NULL,
  `ID_ADMIN` varchar(30) DEFAULT NULL,
  `NAMA_BARANG` varchar(40) DEFAULT NULL,
  `JUMLAH` varchar(35) DEFAULT NULL,
  `TANGGAL` date DEFAULT NULL,
  `HARGA` varchar(35) DEFAULT NULL,
  `TOTAL` int(11) DEFAULT NULL,
  `BAYAR` int(11) DEFAULT NULL,
  `KEMBALIAN` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `transaksi`
--

INSERT INTO `transaksi` (`ID_TRANSAKSI`, `ID_ADMIN`, `NAMA_BARANG`, `JUMLAH`, `TANGGAL`, `HARGA`, `TOTAL`, `BAYAR`, `KEMBALIAN`) VALUES
('00001', NULL, 'Betadine', '1', '2024-07-23', '10000', 10000, 100000, 90000),
('00002', NULL, 'komix', '1', '2024-07-25', '2000', 2000, 100000, 98000);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`ID_ADMIN`);

--
-- Indexes for table `data_penjualan`
--
ALTER TABLE `data_penjualan`
  ADD PRIMARY KEY (`NOMER`),
  ADD KEY `FK_MEMPROSES` (`ID_TRANSAKSI`),
  ADD KEY `FK_MEMPROSESS` (`ID_PERAMALAN`),
  ADD KEY `FK_MENGURANGI` (`ID_STOK`);

--
-- Indexes for table `hasil`
--
ALTER TABLE `hasil`
  ADD PRIMARY KEY (`NO`),
  ADD KEY `FK_MELIHAT` (`ID_PERAMALAN`);

--
-- Indexes for table `peramalan`
--
ALTER TABLE `peramalan`
  ADD PRIMARY KEY (`ID_PERAMALAN`);

--
-- Indexes for table `stok`
--
ALTER TABLE `stok`
  ADD PRIMARY KEY (`ID_STOK`);

--
-- Indexes for table `transaksi`
--
ALTER TABLE `transaksi`
  ADD PRIMARY KEY (`ID_TRANSAKSI`),
  ADD KEY `FK_MELAKUKAN` (`ID_ADMIN`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `hasil`
--
ALTER TABLE `hasil`
  MODIFY `NO` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4638;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `data_penjualan`
--
ALTER TABLE `data_penjualan`
  ADD CONSTRAINT `FK_MEMPROSES` FOREIGN KEY (`ID_TRANSAKSI`) REFERENCES `transaksi` (`ID_TRANSAKSI`),
  ADD CONSTRAINT `FK_MEMPROSESS` FOREIGN KEY (`ID_PERAMALAN`) REFERENCES `peramalan` (`ID_PERAMALAN`),
  ADD CONSTRAINT `FK_MENGURANGI` FOREIGN KEY (`ID_STOK`) REFERENCES `stok` (`ID_STOK`);

--
-- Constraints for table `hasil`
--
ALTER TABLE `hasil`
  ADD CONSTRAINT `FK_MELIHAT` FOREIGN KEY (`ID_PERAMALAN`) REFERENCES `peramalan` (`ID_PERAMALAN`);

--
-- Constraints for table `transaksi`
--
ALTER TABLE `transaksi`
  ADD CONSTRAINT `FK_MELAKUKAN` FOREIGN KEY (`ID_ADMIN`) REFERENCES `admin` (`ID_ADMIN`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
