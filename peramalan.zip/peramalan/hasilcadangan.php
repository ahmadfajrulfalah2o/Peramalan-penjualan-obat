<?php
session_start();
require_once "koneksi.php"; // File ini berisi kode untuk koneksi ke database

// Fungsi untuk menghasilkan primary key otomatis
function generatePrimaryKey($prefix, $table, $column, $connection) {
    $query = "SELECT MAX(CAST(SUBSTRING($column, 2) AS UNSIGNED)) AS max_id FROM $table";
    $result = $connection->query($query);
    $row = $result->fetch_assoc();
    $max_id = isset($row['max_id']) ? $row['max_id'] : 0;
    $new_id = $max_id + 1;
    return $prefix . str_pad($new_id, 4, '0', STR_PAD_LEFT);
}

// Mengambil data penjualan
$queryPenjualan = "SELECT NAMA_BARANG, BULAN, TAHUN, JUMLAH_TERJUAL FROM data_penjualan ORDER BY TAHUN ASC, BULAN ASC";
$resultPenjualan = $connection->query($queryPenjualan);
$dataPenjualan = [];
while ($row = $resultPenjualan->fetch_assoc()) {
    $dataPenjualan[] = $row;
}

// Menghitung peramalan dengan metode Single Moving Average
$periode = 3;
$peramalan = [];
$errorForecast = [];
$errorForecastSquared = [];
$totalErrorSquared = 0;

for ($i = 0; $i < count($dataPenjualan); $i++) {
    if ($i < $periode) {
        $forecast = 0; // Forecast awal untuk bulan 1, 2, 3 adalah 0
    } else {
        $sum = 0;
        for ($j = $i - $periode; $j < $i; $j++) {
            $sum += $dataPenjualan[$j]['JUMLAH_TERJUAL'];
        }
        $forecast = $sum / $periode;
    }
    
    $actual = $dataPenjualan[$i]['JUMLAH_TERJUAL'];
    $error = $actual - $forecast;
    $errorSquared = pow($error, 2);

    $peramalan[] = [
        'NAMA_BARANG' => $dataPenjualan[$i]['NAMA_BARANG'],
        'BULAN' => $dataPenjualan[$i]['BULAN'],
        'TAHUN' => $dataPenjualan[$i]['TAHUN'],
        'JUMLAH_TERJUAL' => $actual,
        'HASIL_RAMAL' => $forecast,
        'ERROR' => $error,
        'ERROR2' => $errorSquared
    ];

    if ($i >= $periode) {
        $totalErrorSquared += $errorSquared;
    }
}

// Menambahkan peramalan untuk Januari 2024
$sum = 0;
for ($i = count($dataPenjualan) - $periode; $i < count($dataPenjualan); $i++) {
    $sum += $dataPenjualan[$i]['JUMLAH_TERJUAL'];
}
$forecastJanuari2024 = $sum / $periode;

$peramalan[] = [
    'NAMA_BARANG' => $dataPenjualan[count($dataPenjualan) - 1]['NAMA_BARANG'],
    'BULAN' => 1,
    'TAHUN' => 2024,
    'JUMLAH_TERJUAL' => null,
    'HASIL_RAMAL' => $forecastJanuari2024,
    'ERROR' => 0,
    'ERROR2' => 0
];

// Menghitung RMSE
$rmse = count($peramalan) > $periode ? sqrt($totalErrorSquared / (count($peramalan) - $periode)) : 0;

// Menyimpan hasil peramalan ke dalam tabel `peramalan` dan `hasil`
foreach ($peramalan as $p) {
    $idPeramalan = generatePrimaryKey('P', 'peramalan', 'ID_PERAMALAN', $connection);

    // Menyimpan ke tabel peramalan
    $queryInsertPeramalan = "INSERT INTO peramalan (ID_PERAMALAN, BULAN, TAHUN, HASIL_RAMAL, ERROR, ERROR2) VALUES (?, ?, ?, ?, ?, ?)";
    $stmtPeramalan = $connection->prepare($queryInsertPeramalan);
    $stmtPeramalan->bind_param("ssssdd", $idPeramalan, $p['BULAN'], $p['TAHUN'], $p['HASIL_RAMAL'], $p['ERROR'], $p['ERROR2']);
    $stmtPeramalan->execute();

    // Menyimpan ke tabel hasil
    $idHasil = generatePrimaryKey('H', 'hasil', 'NO', $connection);
    $queryInsertHasil = "INSERT INTO hasil (NO, ID_PERAMALAN, NAMA_BARANG, BULAN, TAHUN) VALUES (?, ?, ?, ?, ?)";
    $stmtHasil = $connection->prepare($queryInsertHasil);
    $stmtHasil->bind_param("sssss", $idHasil, $idPeramalan, $p['NAMA_BARANG'], $p['BULAN'], $p['TAHUN']);
    $stmtHasil->execute();
}

// Menampilkan hasil peramalan
$queryHasil = "SELECT h.BULAN, h.TAHUN, h.NAMA_BARANG, dp.JUMLAH_TERJUAL, p.HASIL_RAMAL, p.ERROR, p.ERROR2 
               FROM hasil h
               JOIN peramalan p ON h.ID_PERAMALAN = p.ID_PERAMALAN
               LEFT JOIN data_penjualan dp ON h.NAMA_BARANG = dp.NAMA_BARANG AND h.BULAN = dp.BULAN AND h.TAHUN = dp.TAHUN
               WHERE h.TAHUN = 2023 OR (h.TAHUN = 2024 AND h.BULAN <= 1)
               ORDER BY h.TAHUN ASC, h.BULAN ASC";
$resultHasil = $connection->query($queryHasil);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hasil Peramalan</title>
    <!-- Bootstrap CSS -->
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
</head>

<body>
    <div class="container">
        <h1 class="my-4">Hasil Peramalan</h1>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>Bulan</th>
                    <th>Tahun</th>
                    <th>Nama Barang</th>
                    <th>Jumlah Terjual</th>
                    <th>Hasil Peramalan</th>
                    <th>Error Forecast</th>
                    <th>Error Forecast Squared</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($row = $resultHasil->fetch_assoc()) { ?>
                    <tr>
                        <td><?php echo $row['BULAN']; ?></td>
                        <td><?php echo $row['TAHUN']; ?></td>
                        <td><?php echo $row['NAMA_BARANG']; ?></td>
                        <td><?php echo number_format($row['JUMLAH_TERJUAL'], 0); ?></td>
                        <td><?php echo number_format($row['HASIL_RAMAL'], 0); ?></td>
                        <td><?php echo number_format($row['ERROR'], 0); ?></td>
                        <td><?php echo number_format($row['ERROR2'], 0); ?></td>
                    </tr>
                <?php } ?>
            </tbody>
        </table>
        <h3>RMSE: <?php echo $rmse; ?></h3>
        <a href="transaksi.php" class="btn btn-secondary">Kembali</a>
    </div>

    <!-- Bootstrap JS dan Popper.js -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.3/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>

</html>
