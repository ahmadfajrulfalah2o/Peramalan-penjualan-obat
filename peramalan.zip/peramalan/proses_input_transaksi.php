<?php
session_start();
require_once "koneksi.php";

if (!isset($_SESSION['ID_ADMIN'])) {
    die("Anda harus login terlebih dahulu");
}

// Mengambil data dari form
$nama_barang = $_POST['nama_barang'];
$jumlah = $_POST['jumlah'];
$bayar = str_replace('.', '', $_POST['bayar']); // Menghapus titik dari format rupiah
$grand_total = str_replace('.', '', $_POST['grand_total']);

// Fungsi untuk menghasilkan ID_TRANSAKSI
function generateIDTransaksi($prefix, $connection) {
    // Mengambil jumlah data di tabel transaksi
    $queryCount = "SELECT COUNT(*) AS count FROM transaksi";
    $resultCount = $connection->query($queryCount);
    $rowCount = $resultCount->fetch_assoc();
    $count = $rowCount['count'] + 1; // Ditambah 1 untuk ID transaksi baru

    // Menghasilkan ID_TRANSAKSI dengan format yang diinginkan
    return $prefix . str_pad($count, 4, '0', STR_PAD_LEFT);
}

// Mengambil digit pertama dari ID_ADMIN
$ID_ADMIN = $_SESSION['ID_ADMIN'];
$prefix = substr($ID_ADMIN, 0, 1);

// Mengambil tanggal saat ini
$tanggal = date('Y-m-d');

$transaksiBerhasil = true;

// Memasukkan data ke tabel transaksi untuk setiap barang
foreach ($nama_barang as $index => $barang) {
    $queryStok = "SELECT * FROM stok WHERE NAMA_BARANG = ?";
    $stmtStok = $connection->prepare($queryStok);
    $stmtStok->bind_param("s", $barang);
    $stmtStok->execute();
    $resultStok = $stmtStok->get_result();
    $stokData = $resultStok->fetch_assoc();

    if (!$stokData) {
        die("Stok tidak ditemukan");
    }

    $ID_STOK = $stokData['ID_STOK'];
    $harga = $stokData['HARGA'];
    $total = $jumlah[$index] * $harga;

    $ID_TRANSAKSI = generateIDTransaksi($prefix, $connection); // Menghasilkan ID_TRANSAKSI

    $queryTransaksi = "INSERT INTO transaksi (ID_TRANSAKSI, NAMA_BARANG, JUMLAH, HARGA, TOTAL, BAYAR, KEMBALIAN, TANGGAL) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
    $stmtTransaksi = $connection->prepare($queryTransaksi);
    $kembalian = $bayar - $grand_total; // Hitung kembalian di sini sesuai total keseluruhan
    if ($kembalian < 0) {
        $kembalian = 0;
    }
    $stmtTransaksi->bind_param("ssiiiiis", $ID_TRANSAKSI, $barang, $jumlah[$index], $harga, $total, $bayar, $kembalian, $tanggal);

    if (!$stmtTransaksi->execute()) {
        echo "<script>alert('Error: " . $stmtTransaksi->error . "')</script>";
        $transaksiBerhasil = false;
        break;
    } else {
        // Memeriksa apakah entri di data_penjualan sudah ada
        $bulan = date('m');
        $tahun = date('Y');
        $queryCheck = "SELECT NOMER, JUMLAH_TERJUAL FROM data_penjualan WHERE NAMA_BARANG = ? AND BULAN = ? AND TAHUN = ?";
        $stmtCheck = $connection->prepare($queryCheck);
        $stmtCheck->bind_param("sii", $barang, $bulan, $tahun);
        $stmtCheck->execute();
        $resultCheck = $stmtCheck->get_result();

        if ($resultCheck->num_rows > 0) {
            // Entri sudah ada, lakukan update
            $row = $resultCheck->fetch_assoc();
            $nomer = $row['NOMER'];
            $jumlah_terjual = $row['JUMLAH_TERJUAL'] + $jumlah[$index];

            $queryUpdate = "UPDATE data_penjualan SET JUMLAH_TERJUAL = ? WHERE NOMER = ?";
            $stmtUpdate = $connection->prepare($queryUpdate);
            $stmtUpdate->bind_param("ii", $jumlah_terjual, $nomer);
            $stmtUpdate->execute();
        } else {
            // Entri tidak ada, lakukan insert
            // Menghasilkan nilai NOMER baru
            $queryMaxNomer = "SELECT MAX(CAST(NOMER AS UNSIGNED)) AS max_nomer FROM data_penjualan";
            $resultMaxNomer = $connection->query($queryMaxNomer);
            $rowMaxNomer = $resultMaxNomer->fetch_assoc();
            $max_nomer = isset($rowMaxNomer['max_nomer']) ? (int)$rowMaxNomer['max_nomer'] : 0;
            $new_nomer = $max_nomer + 1;

            $queryInsert = "INSERT INTO data_penjualan (NOMER, NAMA_BARANG, BULAN, TAHUN, JUMLAH_TERJUAL) VALUES (?, ?, ?, ?, ?)";
            $stmtInsert = $connection->prepare($queryInsert);
            $stmtInsert->bind_param("isiii", $new_nomer, $barang, $bulan, $tahun, $jumlah[$index]);
            $stmtInsert->execute();
        }

        // Mengurangi jumlah stok
        $queryUpdateStok = "UPDATE stok SET JUMLAH = JUMLAH - ? WHERE ID_STOK = ?";
        $stmtUpdateStok = $connection->prepare($queryUpdateStok);
        $stmtUpdateStok->bind_param("is", $jumlah[$index], $ID_STOK);
        $stmtUpdateStok->execute();
    }
}

if ($transaksiBerhasil) {
    echo "<script>alert('Transaksi berhasil!'); window.location.href = 'owner_dashboard.php';</script>";
} else {
    echo "<script>alert('Terjadi kesalahan saat melakukan transaksi.')</script>";
}
?>
