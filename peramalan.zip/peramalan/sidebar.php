<ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">
    <!-- Sidebar - Brand -->
    <a class="sidebar-brand d-flex align-items-center justify-content-center" href="index.php">
        <div class="sidebar-brand-text mx-3">Fega Farma</div>
    </a>

    <!-- Divider -->
    <hr class="sidebar-divider my-0">

    <!-- Nav Item - Dashboard -->
    <li class="nav-item active">
        <a class="nav-link" href="owner_dashboard.php">
            <i class="fas fa-fw fa-tachometer-alt"></i>
            <span>DATA TRANSAKSI</span>
        </a>
    </li>

    <li class="nav-item">
        <a class="nav-link" href="penjualan.php">
            <i class="fas fa-fw fa-table"></i>
            <span>DATA PENJUALAN</span>
        </a>
    </li>

    <li class="nav-item">
        <a class="nav-link" href="stok.php">
            <i class="fas fa-fw fa-table"></i>
            <span>DATA STOK</span>
        </a>
    </li>

    <li class="nav-item">
        <a class="nav-link" href="proses_peramalan.php">
            <i class="fas fa-fw fa-table"></i>
            <span>PREDIKSI</span>
        </a>
    </li>

    <li class="nav-item">
        <a class="nav-link" href="hasil_prediksi.php">
            <i class="fas fa-fw fa-table"></i>
            <span>HASIL PREDIKSI</span>
        </a>
    </li>

    <?php if ($_SESSION['role'] == 'owner') : ?>
        <li class="nav-item">
            <a class="nav-link" href="karyawan.php">
                <i class="fas fa-fw fa-table"></i>
                <span>DATA KARYAWAN</span>
            </a>
        </li>
    <?php endif; ?>

    <li class="nav-item">
        <a class="nav-link" href="logout.php">
            <span>LOG OUT</span>
        </a>
    </li>

    <!-- Divider -->
    <hr class="sidebar-divider d-none d-md-block">

    <!-- Sidebar Toggler (Sidebar) -->
    <div class="text-center d-none d-md-inline">
        <button class="rounded-circle border-0" id="sidebarToggle"></button>
    </div>
</ul>