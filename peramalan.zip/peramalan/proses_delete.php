<?php
session_start();
require_once "koneksi.php"; // File ini berisi kode untuk koneksi ke database

if (!isset($_SESSION['NAMA']) || !isset($_SESSION['role'])) {
    header("Location: index.php");
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['delete'])) {
    if (isset($_POST['id_transaksi'])) {
        $id_transaksi = $_POST['id_transaksi'];
        $queryDeleteTransaksi = "DELETE FROM transaksi WHERE ID_TRANSAKSI = ?";
        $stmtTransaksi = $connection->prepare($queryDeleteTransaksi);
        $stmtTransaksi->bind_param('s', $id_transaksi);
        $stmtTransaksi->execute();
        $stmtTransaksi->close();
        header("Location: owner_dashboard.php");
        exit();
    }

    if (isset($_POST['nomer'])) {
        $nomer = $_POST['nomer'];
        $queryDeletePenjualan = "DELETE FROM data_penjualan WHERE NOMER = ?";
        $stmtPenjualan = $connection->prepare($queryDeletePenjualan);
        $stmtPenjualan->bind_param('s', $nomer);
        $stmtPenjualan->execute();
        $stmtPenjualan->close();
        header("Location: penjualan.php");
        exit();
    }

    if (isset($_POST['id_admin'])) {
        $nomer = $_POST['id_admin'];
        $queryDeletePenjualan = "DELETE FROM admin WHERE ID_ADMIN = ?";
        $stmtPenjualan = $connection->prepare($queryDeletePenjualan);
        $stmtPenjualan->bind_param('s', $nomer);
        $stmtPenjualan->execute();
        $stmtPenjualan->close();
        header("Location: karyawan.php");
        exit();
    }

    if (isset($_POST['id_stok'])) {
        $id_stok = $_POST['id_stok'];
        $queryDeleteStok = "DELETE FROM stok WHERE ID_STOK = ?";
        $stmtStok = $connection->prepare($queryDeleteStok);
        $stmtStok->bind_param('s', $id_stok);
        $stmtStok->execute();
        $stmtStok->close();
        header("Location: stok.php");
        exit();
    }
} else {
    echo "Invalid request.";
    exit();
}
?>
