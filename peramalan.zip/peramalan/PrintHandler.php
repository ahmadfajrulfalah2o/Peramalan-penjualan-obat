<?php
require_once "koneksi.php"; // File ini berisi kode untuk koneksi ke database

class PrintHandler
{
    private $connection;

    public function __construct($connection)
    {
        $this->connection = $connection;
    }

    public function printPenjualan()
    {
        $query = "SELECT NOMER, NAMA_BARANG, BULAN, TAHUN, JUMLAH_TERJUAL FROM data_penjualan ORDER BY TAHUN ASC, BULAN ASC";
        return $this->executeQuery($query);
    }

    public function printTransaksi()
    {
        // Pilih kolom yang diinginkan saja
        $query = "SELECT ID_TRANSAKSI, NAMA_BARANG, JUMLAH, TANGGAL, HARGA, TOTAL, BAYAR, KEMBALIAN FROM transaksi ORDER BY TANGGAL ASC";
        return $this->executeQuery($query);
    }

    public function printStok()
    {
        $query = "SELECT * FROM stok ORDER BY NAMA_BARANG ASC";
        return $this->executeQuery($query);
    }

    public function printPrediksi($nama_barang)
    {
        $query = "SELECT h.NO, h.BULAN, h.TAHUN, dp.JUMLAH_TERJUAL, p.HASIL_RAMAL, p.ERROR, p.ERROR2, p.RMSE 
                  FROM hasil h
                  JOIN peramalan p ON h.ID_PERAMALAN = p.ID_PERAMALAN
                  JOIN data_penjualan dp ON h.NAMA_BARANG = dp.NAMA_BARANG AND h.BULAN = dp.BULAN AND h.TAHUN = dp.TAHUN
                  WHERE h.NAMA_BARANG = ?
                  ORDER BY h.TAHUN ASC, h.BULAN ASC";
        $stmt = $this->connection->prepare($query);
        $stmt->bind_param("s", $nama_barang);
        $stmt->execute();
        return $stmt->get_result();
    }

    public function printKaryawan()
    {
        $query = "SELECT * FROM admin ORDER BY NAMA ASC";
        return $this->executeQuery($query);
    }

    private function executeQuery($query)
    {
        $result = $this->connection->query($query);
        $data = [];
        while ($row = $result->fetch_assoc()) {
            $data[] = $row;
        }
        return $data;
    }
}

?>
