<?php
require_once "koneksi.php"; // File ini berisi kode untuk koneksi ke database
require_once "PrintHandler.php";

$printHandler = new PrintHandler($connection);
$action = isset($_GET['action']) ? $_GET['action'] : '';
$nama_barang = isset($_GET['nama_barang']) ? $_GET['nama_barang'] : '';

$data = [];
$title = '';

switch ($action) {
    case 'penjualan':
        $data = $printHandler->printPenjualan();
        $title = 'Data Penjualan';
        break;
    case 'transaksi':
        $data = $printHandler->printTransaksi();
        $title = 'Data Transaksi';
        break;
    case 'stok':
        $data = $printHandler->printStok();
        $title = 'Data Stok';
        break;
    case 'prediksi':
        $data = $printHandler->printPrediksi($nama_barang);
        $title = 'Data Prediksi: ' . htmlspecialchars($nama_barang);
        break;
    case 'karyawan':
        $data = $printHandler->printKaryawan();
        $title = 'Data Karyawan';
        break;
    default:
        die("Action not recognized.");
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $title; ?></title>
    <!-- Bootstrap CSS -->
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <style>
        @media print {
            .no-print {
                display: none;
            }
        }
    </style>
</head>

<body>
    <div class="container">
        <h1 class="my-4"><?php echo $title; ?></h1>
        <button class="btn btn-primary no-print" onclick="window.print()">Cetak</button>
        <table class="table table-bordered mt-3">
            <thead>
                <tr>
                    <?php if (!empty($data)) {
                        foreach (array_keys($data[0]) as $column) { ?>
                            <th><?php echo htmlspecialchars($column); ?></th>
                        <?php }
                    } ?>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($data as $row) { ?>
                    <tr>
                        <?php foreach ($row as $value) { ?>
                            <td><?php echo htmlspecialchars($value); ?></td>
                        <?php } ?>
                    </tr>
                <?php } ?>
            </tbody>
        </table>
    </div>

    <!-- Bootstrap JS and dependencies -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.2/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>

</html>
