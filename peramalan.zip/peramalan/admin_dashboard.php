<?php
session_start();
if (!isset($_SESSION['NAMA']) || !isset($_SESSION['role'])) {
    header("Location: index.php");
    exit();
}
require_once "koneksi.php"; // File ini berisi kode untuk koneksi ke database

// Kode halaman admin_dashboard.php di sini...

// Function to format numbers as Rupiah currency
function formatRupiah($number) {
    return 'Rp ' . number_format($number, 0, ',', '.');
}

// Ambil data filter tanggal
$filterTanggal = isset($_GET['filter_tanggal']) ? $_GET['filter_tanggal'] : '';

// Query untuk mengambil data transaksi
$query = "SELECT * FROM transaksi";
if (!empty($filterTanggal)) {
    $query .= " WHERE TANGGAL = '$filterTanggal'";
}
$result = $connection->query($query);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Admin Dashboard</title>

    <!-- Custom fonts for this template-->
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">

    <!-- Custom styles for this template-->
    <link href="css/sb-admin-2.min.css" rel="stylesheet">
</head>

<body id="page-top">
    <!-- Page Wrapper -->
    <div id="wrapper">
        <!-- Sidebar -->
        <?php include 'sidebar.php'; ?>
        <!-- End of Sidebar -->

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">
            <!-- Main Content -->
            <div id="content">
                <!-- Topbar -->
                <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">
                </nav>
                <!-- End of Topbar -->

                <!-- Begin Page Content -->
                <div class="container-fluid">
                    <!-- Page Heading -->
                    <h1 class="h3 mb-2 text-gray-800">DATA TRANSAKSI</h1>
                    <div class="row">
                        <!-- Filter pencarian (sebelah kiri) -->
                        <div class="col-md-6 mb-3">
                            <form class="form-inline" method="GET" action="">
                                <div class="input-group">
                                    <input type="date" class="form-control" name="filter_tanggal" value="<?php echo htmlspecialchars($filterTanggal); ?>">
                                    <div class="input-group-append">
                                        <button class="btn btn-primary" type="submit">CARI</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                        <!-- Tombol tambah data (sebelah kanan) -->
                        <div class="col-md-6 mb-3 text-right">
                            <a href="tambah_transaksi.php" class="btn btn-success">Tambah Data transaksi</a>
                            <a href="print_page.php?action=transaksi" class="btn btn-info" target="_blank">Cetak</a>
                        </div>
                    </div>

                    <!-- DataTales Example -->
                    <div class="card shadow mb-4">
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                    <thead>
                                        <tr>
                                            <th>Nota.</th>
                                            <th>Nama</th>
                                            <th>JUMLAH</th>
                                            <th>TANGGAL</th>
                                            <th>Harga</th>
                                            <th>Total</th>
                                            <th>Bayar</th>
                                            <th>Kembalian</th>
                                            <th>Aksi</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                    <?php
                                        if ($result->num_rows > 0) {
                                            while ($row = $result->fetch_assoc()) {
                                                echo "<tr>";
                                                echo "<td>" . $row['ID_TRANSAKSI'] . "</td>";
                                                echo "<td>" . $row['NAMA_BARANG'] . "</td>";
                                                echo "<td>" . $row['JUMLAH'] . "</td>";
                                                echo "<td>" . $row['TANGGAL'] . "</td>";
                                                echo "<td>" . formatRupiah($row['HARGA']) . "</td>";
                                                echo "<td>" . formatRupiah($row['TOTAL']) . "</td>";
                                                echo "<td>" . formatRupiah($row['BAYAR']) . "</td>";
                                                echo "<td>" . formatRupiah($row['KEMBALIAN']) . "</td>";
                                                echo "<td>";
                                                echo "<form action='proses_delete.php' method='POST' style='display: inline;'>";
                                                echo "<input type='hidden' name='id_transaksi' value='" . $row['ID_TRANSAKSI'] . "'>";
                                                echo "<button type='submit' name='delete' class='btn btn-danger btn-sm'>Delete</button>";
                                                echo "</form>";
                                                echo "</td>";
                                                echo "</tr>";
                                            }
                                        } else {
                                            echo "<tr><td colspan='9'>Tidak ada data transaksi.</td></tr>";
                                        }
                                    ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- /.container-fluid -->
            </div>
            <!-- End of Main Content -->

            <script>
                document.addEventListener('DOMContentLoaded', function() {
                    var searchInput = document.getElementById('searchInput');
                    var searchButton = document.getElementById('searchButton');

                    searchInput.addEventListener('input', filterTable);
                    searchButton.addEventListener('click', filterTable);

                    function filterTable() {
                        var keyword = searchInput.value.toLowerCase();
                        var rows = document.querySelectorAll('#dataTable tbody tr');

                        rows.forEach(function(row) {
                            var namaBarang = row.querySelector('td:nth-child(2)').textContent.toLowerCase();
                            if (namaBarang.includes(keyword)) {
                                row.style.display = '';
                            } else {
                                row.style.display = 'none';
                            }
                        });
                    }
                });
            </script>

            <!-- Footer -->
            <footer class="sticky-footer bg-white">
                <div class="container my-auto">
                    <div class="copyright text-center my-auto">
                        <span>Copyright &copy; Apotek Fega Farma 2024</span>
                    </div>
                </div>
            </footer>
            <!-- End of Footer -->
        </div>
        <!-- End of Content Wrapper -->
    </div>
    <!-- End of Page Wrapper -->

    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>

    <!-- Logout Modal-->
    <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
        aria-hidden="true">
    </div>
</body>

</html>
