<?php
session_start();
require_once "koneksi.php"; // File ini berisi kode untuk koneksi ke database

// Mengambil data hasil peramalan
$queryHasil = "SELECT h.BULAN, h.TAHUN, h.NAMA_BARANG, dp.JUMLAH_TERJUAL, p.HASIL_RAMAL, p.ERROR, p.ERROR2, h.ID_PERAMALAN, p.PERIODE, p.RMSE, p.TOTAL_ERROR_KUADRAT
               FROM hasil h
               JOIN peramalan p ON h.ID_PERAMALAN = p.ID_PERAMALAN
               LEFT JOIN data_penjualan dp ON h.NAMA_BARANG = dp.NAMA_BARANG AND h.BULAN = dp.BULAN AND h.TAHUN = dp.TAHUN
               ORDER BY h.NAMA_BARANG ASC, p.PERIODE ASC, h.TAHUN ASC, h.BULAN ASC";
$resultHasil = $connection->query($queryHasil);

$groupedResults = [];
while ($row = $resultHasil->fetch_assoc()) {
    $groupedResults[$row['NAMA_BARANG']][$row['PERIODE']][] = $row;
}
// Mendapatkan daftar barang untuk opsi penghapusan
$queryBarang = "SELECT DISTINCT NAMA_BARANG FROM data_penjualan ORDER BY NAMA_BARANG ASC";
$resultBarang = $connection->query($queryBarang);
$namaBarangList = [];
while ($row = $resultBarang->fetch_assoc()) {
    $namaBarangList[] = $row['NAMA_BARANG'];
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Prediksi</title>

    <!-- Custom fonts for this template-->
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">

    <!-- Custom styles for this template-->
    <link href="css/sb-admin-2.min.css" rel="stylesheet">
    <!-- Bootstrap CSS -->
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
</head>

<body id="page-top">

    <!-- Page Wrapper -->
    <div id="wrapper">

        <!-- Sidebar -->
        <?php include 'sidebar.php'; ?>
        <!-- End of Sidebar -->

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

                <!-- Topbar -->
                <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">
                    <!-- Topbar Navbar -->
                    <ul class="navbar-nav ml-auto">
                        <!-- Nav Item - User Information -->
                        <li class="nav-item dropdown no-arrow">
                            <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <span class="mr-2 d-none d-lg-inline text-gray-600 small">
                                    <?php echo isset($_SESSION['NAMA']) ? htmlspecialchars($_SESSION['NAMA']) : 'Guest'; ?>
                                </span>
                                <img class="img-profile rounded-circle" src="img/undraw_profile.svg">
                            </a>
                        </li>
                    </ul>
                </nav>
                <!-- End of Topbar -->

                <!-- Begin Page Content -->
                <div class="container-fluid">

                    <h1 class="h3 mb-2 text-gray-800">HASIL PREDIKSI</h1>

                    <div class="row mb-4">
                        <div class="col-md-6">
                            <form method="post" action="hapus_semua_prediksi.php">
                                <div class="form-group">
                                    <label for="nama_barang_hapus">Nama Barang yang Akan Dihapus:</label>
                                    <input list="nama_barang_hapus_list" class="form-control" id="nama_barang_hapus" name="nama_barang_hapus" required>
                                    <datalist id="nama_barang_hapus_list">
                                        <?php foreach ($namaBarangList as $namaBarang): ?>
                                            <option value="<?php echo htmlspecialchars($namaBarang); ?>">
                                        <?php endforeach; ?>
                                    </datalist>
                                </div>
                                <button type="submit" class="btn btn-danger">Hapus Semua Prediksi untuk Barang Ini</button>
                            </form>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <form class="form-inline">
                                <div class="input-group">
                                    <input type="text" class="form-control" id="searchInput" placeholder="Cari berdasarkan nama...">
                                    <div class="input-group-append">
                                        <button class="btn btn-primary" type="button" id="searchButton">Cari</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                    <div class="card shadow mb-4">
    <div class="card-body">
        <div class="table-responsive">
            <?php if (!empty($groupedResults)): ?>
                <?php foreach ($groupedResults as $namaBarang => $periodeResults): ?>
                    <div class="barang-container">
                        <h2 class="barang-title"><?php echo htmlspecialchars($namaBarang); ?></h2>
                        <?php foreach ($periodeResults as $periode => $results): ?>
                            <?php 
                            $totalErrorSquared = 0;
                            $countError = 0;
                            $periods = [];
                            foreach ($results as $row) {
                                $periods[] = $row['BULAN'] . ' ' . $row['TAHUN'];
                                if ($row['HASIL_RAMAL'] !== null) {
                                    $totalErrorSquared += $row['ERROR2'];
                                    if ($row['JUMLAH_TERJUAL'] !== null) {
                                        $countError++;
                                    }
                                }
                            }
                            $rmse = $countError > 0 ? sqrt($totalErrorSquared / $countError) : 0;
                            $periodString = implode(', ', array_unique($periods));
                            ?>
                            <div class="periode-container">
                                <h3 class="periode-title">Periode: <?php echo htmlspecialchars($periode); ?> bulan</h3>
                                <table class="table table-bordered mt-4">
                                    <thead>
                                        <tr>
                                            <th>No</th>
                                            <th>Bulan</th>
                                            <th>Tahun</th>
                                            <th>Penjualan</th>
                                            <th>Hasil Peramalan</th>
                                            <th>Error Forecast</th>
                                            <th>Error Forecast Squared</th>
                                            <th>Hapus</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($results as $index => $row): ?>
                                            <tr>
                                                <td><?php echo $index + 1; ?></td>
                                                <td><?php echo $row['BULAN']; ?></td>
                                                <td><?php echo $row['TAHUN']; ?></td>
                                                <td><?php echo is_null($row['JUMLAH_TERJUAL']) ? '' : round($row['JUMLAH_TERJUAL']); ?></td>
                                                <td><?php echo is_null($row['HASIL_RAMAL']) ? '' : round($row['HASIL_RAMAL']); ?></td>
                                                <td><?php echo is_null($row['ERROR']) ? '' : round($row['ERROR']); ?></td>
                                                <td><?php echo is_null($row['ERROR2']) ? '' : round($row['ERROR2']); ?></td>
                                                <td>
                                                    <form method="POST" action="hapus_prediksi.php">
                                                        <input type="hidden" name="id_peramalan" value="<?php echo $row['ID_PERAMALAN']; ?>">
                                                        <button type="submit" class="btn btn-danger btn-sm">Hapus</button>
                                                    </form>
                                                </td>
                                            </tr> 
                                        <?php endforeach; ?>
                                    </tbody>
                                    <tfoot>
                                        <tr>
                                            <td colspan="6"><strong>Total</strong></td>
                                            <td><?php echo $totalErrorSquared; ?></td>
                                        </tr>
                                        <tr>
                                            <td colspan="7" class="text-right">
                                                <strong>RMSE: <?php echo $rmse; ?></strong>
                                            </td>
                                        </tr>
                                    </tfoot>
                                </table>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endforeach; ?>
            <?php else: ?>
                <p class="text-muted">Tidak ada data prediksi sebelumnya.</p>
            <?php endif; ?>
        </div>
    </div>
</div>

                <!-- /.container-fluid -->

            </div>
            <!-- End of Main Content -->

        </div>
        <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->

    <!-- Bootstrap core JavaScript-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Custom scripts for all pages-->
    <script src="js/sb-admin-2.min.js"></script>

    <script>
        document.getElementById('searchButton').addEventListener('click', function() {
            var input = document.getElementById('searchInput').value.toLowerCase();
            var barangContainers = document.querySelectorAll('.barang-container');

            barangContainers.forEach(function(container) {
                var title = container.querySelector('.barang-title').textContent.toLowerCase();
                if (title.includes(input)) {
                    container.style.display = '';
                } else {
                    container.style.display = 'none';
                }
            });
        });
    </script>
</body>

</html> 