<?php
require_once "koneksi.php";

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nama_barang = $_POST['nama_barang'];
    $query = "SELECT ID_STOK, NAMA_BARANG, HARGA, JUMLAH FROM stok WHERE NAMA_BARANG LIKE ?";
    $stmt = $connection->prepare($query);
    $param = "%" . $nama_barang . "%";
    $stmt->bind_param("s", $param);
    $stmt->execute();
    $result = $stmt->get_result();
    
    $stokList = [];
    while ($row = $result->fetch_assoc()) {
        $stokList[] = $row;
    }
    echo json_encode($stokList);
}
?>
