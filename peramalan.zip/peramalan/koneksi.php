<?php
$host = 'localhost';
$username = 'root';
$password = '';
$dbname = 'apotek';
$connection = new mysqli($host, $username, $password, $dbname);

// Periksa koneksi
if ($connection->connect_error) {
    die("Koneksi gagal: " . $connection->connect_error);
}
?>
