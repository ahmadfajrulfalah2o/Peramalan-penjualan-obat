<?php
session_start();
require_once "koneksi.php"; // File ini berisi kode untuk koneksi ke database

// Cek apakah pengguna sudah login dan memiliki peran sebagai owner
if (!isset($_SESSION['NAMA']) || !isset($_SESSION['role']) || $_SESSION['role'] != 'owner') {
    header("Location: index.php"); // Alihkan ke halaman utama atau halaman lain
    exit();
}

// Kode halaman karyawan.php di sini...
?>
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Karyawan</title>

    <!-- Custom fonts for this template-->
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">

    <!-- Custom styles for this template-->
    <link href="css/sb-admin-2.min.css" rel="stylesheet">

</head>

<body id="page-top">

    <!-- Page Wrapper -->
    <div id="wrapper">

        <!-- Sidebar -->
        <?php include 'sidebar.php'; ?>
        <!-- End of Sidebar -->

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

                <!-- Topbar -->
                <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">
                </nav>
                <!-- End of Topbar -->

                <!-- Begin Page Content -->
                <div class="container-fluid">

                    <!-- Page Heading -->
                    <!-- Page Heading -->
                    <h1 class="h3 mb-2 text-gray-800">DATA KARYAWAN</h1>
                    <div class="row">
                        <!-- Filter pencarian (sebelah kiri) -->
                        <div class="col-md-6 mb-3">
                            <form class="form-inline">
                                <div class="input-group">
                                    <input type="text" class="form-control" id="searchInput" placeholder="Cari berdasarkan nama...">
                                    <div class="input-group-append">
                                        <button class="btn btn-primary" type="button" id="searchButton">Cari</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                        <!-- Tombol tambah data (sebelah kanan) -->
                        <div class="col-md-6 mb-3 text-right">
                            <a href="tambah_karyawan.php" class="btn btn-success">Tambah Karyawan</a>
                            <a href="print_page.php?action=karyawan" class="btn btn-info" target="_blank">Cetak</a>
                        </div>
                    </div>
                    <!-- DataTales Example -->

                    <!-- DataTales Example -->
                    <div class="card shadow mb-4">
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                    <thead>
                                        <tr>
                                            <th>ID KARYAWAN</th>
                                            <th>NAMA</th>
                                            <th>ROLE</th>
                                            <th>Aksi</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                    <?php
                                        $query = "SELECT * FROM admin";
                                        $result = $connection->query($query);

                                        if ($result->num_rows > 0) {
                                            while ($row = $result->fetch_assoc()) {
                                                echo "<tr>";
                                                echo "<td>" . $row['ID_ADMIN'] . "</td>";
                                                echo "<td>" . $row['NAMA'] . "</td>";
                                                echo "<td>" . $row['role'] . "</td>";
                                                echo "<td>";
                                                echo "<form action='proses_delete.php' method='POST' style='display: inline;'>";
                                                echo "<input type='hidden' name='id_admin' value='" . $row['ID_ADMIN'] . "'>";
                                                echo "<button type='submit' name='delete' class='btn btn-danger btn-sm'>Delete</button>";
                                                echo "</form>";
                                                echo "</td>";
                                                echo "</tr>";
                                            }
                                        } else {
                                            echo "<tr><td colspan='8'>Tidak ada data transaksi.</td></tr>";
                                        }
                                        ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                <!-- /.container-fluid -->


            </div>
            <!-- End of Main Content -->
            <script>
    document.addEventListener('DOMContentLoaded', function() {
        var searchInput = document.getElementById('searchInput');
        var searchButton = document.getElementById('searchButton');

        searchInput.addEventListener('input', filterTable);
        searchButton.addEventListener('click', filterTable);

        function filterTable() {
            var keyword = searchInput.value.toLowerCase();
            var rows = document.querySelectorAll('#dataTable tbody tr');

            rows.forEach(function(row) {
                var namaBarang = row.querySelector('td:nth-child(2)').textContent.toLowerCase();
                if (namaBarang.includes(keyword)) {
                    row.style.display = '';
                } else {
                    row.style.display = 'none';
                }
            });
        }
    });
</script>

            <!-- Footer -->
            <footer class="sticky-footer bg-white">
                <div class="container my-auto">
                    <div class="copyright text-center my-auto">
                        <span>Copyright &copy; Apotek Fega Farma</span>
                    </div>
                </div>
            </footer>
            <!-- End of Footer -->

        </div>
        <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->

    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>

    <!-- Logout Modal-->
    <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
        aria-hidden="true">
        <div
