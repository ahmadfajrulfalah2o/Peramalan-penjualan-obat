<?php
session_start();
require_once "koneksi.php"; // File ini berisi kode untuk koneksi ke database

// Mengecek apakah user telah login
if (!isset($_SESSION['NAMA']) || !isset($_SESSION['role'])) {
    header("Location: index.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $namaBarang = $_POST['nama_barang_hapus'];

    // Menghapus data peramalan dan hasil berdasarkan nama barang
    $queryDelete = "DELETE p, h 
                    FROM peramalan p 
                    JOIN hasil h ON p.ID_PERAMALAN = h.ID_PERAMALAN 
                    WHERE h.NAMA_BARANG = ?";
    $stmtDelete = $connection->prepare($queryDelete);
    $stmtDelete->bind_param("s", $namaBarang);
    if ($stmtDelete->execute()) {
        $_SESSION['message'] = "Semua data prediksi untuk barang '$namaBarang' berhasil dihapus.";
    } else {
        $_SESSION['error'] = "Gagal menghapus data prediksi untuk barang '$namaBarang'.";
    }

    header("Location: hasil_prediksi.php");
    exit();
} else {
    header("Location: hasil_prediksi.php");
    exit();
}
?>
