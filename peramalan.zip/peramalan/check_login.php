<?php
session_start();
require_once "koneksi.php"; // File ini berisi kode untuk koneksi ke database

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $NAMA = $_POST['NAMA'];
    $PASSWORD = $_POST['PASSWORD'];
    $role = $_POST['role'];

    // Menggunakan koneksi yang sudah ada
    global $connection;

    // Query ke database untuk memeriksa apakah username, password, dan role valid
    $query = "SELECT * FROM admin WHERE NAMA = ? AND PASSWORD = ? AND role = ?";
    $stmt = $connection->prepare($query);
    $stmt->bind_param("sss", $NAMA, $PASSWORD, $role);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result && $result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $_SESSION['NAMA'] = $row['NAMA'];
        $_SESSION['role'] = $row['role'];
        $_SESSION['ID_ADMIN'] = $row['ID_ADMIN']; // Menyimpan ID_ADMIN ke dalam sesi

        // Redirect sesuai dengan role pengguna
        if ($role === 'pegawai') {
            header("Location: admin_dashboard.php");
            exit;
        } elseif ($role === 'owner') {
            header("Location: owner_dashboard.php");
            exit;
        }
    } else {
        header("Location: index.php?error=1");
        exit;
    }
}
?>
