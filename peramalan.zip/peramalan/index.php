<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Form Login</title>
    <!-- Bootstrap CSS -->
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header">
                        <h3 class="text-center">Fega Farma</h3>
                    </div>
                    <div class="card-body">
                        <form action="check_login.php" method="POST">
                            <div class="form-group">
                                <label for="NAMA">Nama:</label>
                                <input type="text" id="NAMA" name="NAMA" class="form-control">
                            </div>
                            <div class="form-group">
                                <label for="PASSWORD">Password:</label>
                                <input type="password" id="PASSWORD" name="PASSWORD" class="form-control">
                            </div>
                            <div class="form-group">
                                <label for="role">Role:</label>
                                <select id="role" name="role" class="form-control">
                                    <option value="pegawai">pegawai</option>
                                    <option value="owner">owner</option>
                                </select>
                            </div>
                            <!-- Hidden input for ID_ADMIN -->
                            <input type="hidden" id="ID_ADMIN" name="ID_ADMIN" value="<?php echo isset($_SESSION['ID_ADMIN']) ? $_SESSION['ID_ADMIN'] : ''; ?>">
                            <button type="submit" class="btn btn-primary btn-block">Login</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Bootstrap JS and dependencies -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.3/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
