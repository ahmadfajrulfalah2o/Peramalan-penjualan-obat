<?php
session_start();
require_once "koneksi.php"; // File ini berisi kode untuk koneksi ke database

if (!isset($_SESSION['NAMA']) || !isset($_SESSION['role'])) {
    header("Location: index.php");
    exit();
}

if (isset($_GET['id'])) {
    $id_stok = $_GET['id'];

    $query = "SELECT * FROM stok WHERE ID_STOK = '$id_stok'";
    $result = $connection->query($query);

    if ($result->num_rows == 1) {
        $row = $result->fetch_assoc();
        $nama_barang = $row['NAMA_BARANG'];
        $jumlah = $row['JUMLAH'];
        $harga = $row['HARGA'];
    } else {
        echo "Data stok tidak ditemukan.";
        exit();
    }
} else {
    echo "ID stok tidak ditemukan.";
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nama_barang = $_POST['nama_barang'];
    $jumlah = $_POST['jumlah'];
    $harga = $_POST['harga'];

    $queryUpdate = "UPDATE stok SET NAMA_BARANG = '$nama_barang', JUMLAH = '$jumlah', HARGA = '$harga' WHERE ID_STOK = '$id_stok'";

    if ($connection->query($queryUpdate) === TRUE) {
        header("Location: stok.php");
        exit();
    } else {
        echo "Error updating record: " . $connection->error;
    }

    $connection->close();
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Stok</title>
    <!-- Bootstrap CSS -->
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
</head>

<body>
    <div class="container">
        <h1 class="my-4">Update Stok</h1>
        <!-- Form for updating stok -->
        <form method="POST">
            <div class="form-group">
                <label for="nama_barang">Nama Barang:</label>
                <input type="text" class="form-control" id="nama_barang" name="nama_barang" value="<?php echo $nama_barang; ?>">
            </div>
            <div class="form-group">
                <label for="jumlah">Jumlah:</label>
                <input type="number" class="form-control" id="jumlah" name="jumlah" value="<?php echo $jumlah; ?>">
            </div>
            <div class="form-group">
                <label for="harga">Harga:</label>
                <input type="number" class="form-control" id="harga" name="harga" value="<?php echo $harga; ?>">
            </div>
            <button type="submit" class="btn btn-primary">Update Stok</button>
            <a href="stok.php" class="btn btn-secondary">Kembali</a>
        </form>
    </div>

    <!-- Bootstrap JS dan Popper.js -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.3/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>

</html>
