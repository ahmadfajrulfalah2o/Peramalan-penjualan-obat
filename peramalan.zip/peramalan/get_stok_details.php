<?php
require_once "koneksi.php";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id_stok = $_POST['id_stok'];

    $query = "SELECT * FROM stok WHERE ID_STOK = '$id_stok'";
    $result = $connection->query($query);

    if ($result->num_rows == 1) {
        $row = $result->fetch_assoc();
        echo json_encode($row);
    } else {
        echo json_encode([]);
    }
}
?>
