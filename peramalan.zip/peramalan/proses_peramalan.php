<?php
session_start();
require_once "koneksi.php"; 

// Fungsi untuk menghasilkan primary key otomatis
function generatePrimaryKey($prefix, $table, $column, $connection) {
    $query = "SELECT MAX(CAST(SUBSTRING($column, 2) AS UNSIGNED)) AS max_id FROM $table";
    $result = $connection->query($query);
    $row = $result->fetch_assoc();
    $max_id = isset($row['max_id']) ? $row['max_id'] : 0;
    $new_id = $max_id + 1;
    return $prefix . str_pad($new_id, 4, '0', STR_PAD_LEFT);
}

// Mengambil daftar nama barang dari tabel data_penjualan
$queryNamaBarang = "SELECT DISTINCT NAMA_BARANG FROM data_penjualan";
$resultNamaBarang = $connection->query($queryNamaBarang);
$namaBarangList = [];
while ($row = $resultNamaBarang->fetch_assoc()) {
    $namaBarangList[] = $row['NAMA_BARANG'];
}

// Mengecek apakah form telah disubmit
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $namaBarang = $_POST['nama_barang'];
    $periode = isset($_POST['periode']) ? (int)$_POST['periode'] : 3;

    // Mengambil data penjualan dengan nama barang yang sesuai
    $queryPenjualan = "SELECT NAMA_BARANG, BULAN, TAHUN, JUMLAH_TERJUAL FROM data_penjualan WHERE NAMA_BARANG = ? ORDER BY TAHUN ASC, BULAN ASC";
    $stmtPenjualan = $connection->prepare($queryPenjualan);
    $stmtPenjualan->bind_param("s", $namaBarang);
    $stmtPenjualan->execute();
    $resultPenjualan = $stmtPenjualan->get_result();
    $dataPenjualan = [];
    while ($row = $resultPenjualan->fetch_assoc()) {
        $dataPenjualan[] = $row;
    }

   
$peramalan = [];
$totalErrorKuadrat = 0;
$jumlahError = 0;

if (count($dataPenjualan) >= $periode) {
    for ($i = 0; $i < count($dataPenjualan); $i++) {
        if ($i < $periode) {
            $ramalan = null; 
            $error = null;
            $errorKuadrat = null;
        } else {
            $jumlah = 0;
            for ($j = $i - $periode; $j < $i; $jumlah += $dataPenjualan[$j]['JUMLAH_TERJUAL'], $j++);
            $ramalan = $jumlah / $periode;
            $aktual = $dataPenjualan[$i]['JUMLAH_TERJUAL'];
            $error = $aktual - $ramalan;
            $errorKuadrat = pow($error, 2);

            $totalErrorKuadrat += $errorKuadrat;
            $jumlahError++;
        }

        $peramalan[] = [
            'NAMA_BARANG' => $dataPenjualan[$i]['NAMA_BARANG'],
            'BULAN' => $dataPenjualan[$i]['BULAN'],
            'TAHUN' => $dataPenjualan[$i]['TAHUN'],
            'JUMLAH_TERJUAL' => $dataPenjualan[$i]['JUMLAH_TERJUAL'],
            'HASIL_RAMAL' => $ramalan,
            'ERROR' => $error,
            'ERROR2' => $errorKuadrat, 
            'PERIODE' => $periode
        ];
    }

    
    $jumlah = 0;
    for ($i = count($dataPenjualan) - $periode; $i < count($dataPenjualan); $jumlah += $dataPenjualan[$i]['JUMLAH_TERJUAL'], $i++);
    $ramalanBerikutnya = $jumlah / $periode;

    $bulanTerakhir = $dataPenjualan[count($dataPenjualan) - 1]['BULAN'];
    $tahunTerakhir = $dataPenjualan[count($dataPenjualan) - 1]['TAHUN'];
    $bulanBerikutnya = $bulanTerakhir + 1;
    $tahunBerikutnya = $tahunTerakhir;

    if ($bulanBerikutnya > 12) {
        $bulanBerikutnya = 1;
        $tahunBerikutnya++;
    }

    $peramalan[] = [
        'NAMA_BARANG' => $namaBarang,
        'BULAN' => $bulanBerikutnya,
        'TAHUN' => $tahunBerikutnya,
        'JUMLAH_TERJUAL' => null,
        'HASIL_RAMAL' => $ramalanBerikutnya,
        'ERROR' => null,
        'ERROR2' => null,
        'PERIODE' => $periode
    ];
}


$rmse = $jumlahError > 0 ? sqrt($totalErrorKuadrat / $jumlahError) : 0;

foreach ($peramalan as $p) {
    $idPeramalan = generatePrimaryKey('P', 'peramalan', 'ID_PERAMALAN', $connection);

    
    $queryInsertPeramalan = "INSERT INTO peramalan (ID_PERAMALAN, BULAN, TAHUN, HASIL_RAMAL, ERROR, ERROR2, PERIODE, TOTAL_ERROR_KUADRAT, RMSE) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
    $stmtPeramalan = $connection->prepare($queryInsertPeramalan);
    $stmtPeramalan->bind_param("sssdddddd", $idPeramalan, $p['BULAN'], $p['TAHUN'], $p['HASIL_RAMAL'], $p['ERROR'], $p['ERROR2'], $p['PERIODE'], $totalErrorKuadrat, $rmse);
    $stmtPeramalan->execute();

    
    $idHasil = generatePrimaryKey('H', 'hasil', 'NO', $connection);
    $queryInsertHasil = "INSERT INTO hasil (NO, ID_PERAMALAN, NAMA_BARANG, BULAN, TAHUN) VALUES (?, ?, ?, ?, ?)";
    $stmtHasil = $connection->prepare($queryInsertHasil);
    $stmtHasil->bind_param("sssss", $idHasil, $idPeramalan, $p['NAMA_BARANG'], $p['BULAN'], $p['TAHUN']);
    $stmtHasil->execute();
}


}

$queryHasil = "SELECT h.BULAN, h.TAHUN, h.NAMA_BARANG, dp.JUMLAH_TERJUAL, p.HASIL_RAMAL, p.ERROR, p.ERROR2 
               FROM hasil h
               JOIN peramalan p ON h.ID_PERAMALAN = p.ID_PERAMALAN
               LEFT JOIN data_penjualan dp ON h.NAMA_BARANG = dp.NAMA_BARANG AND h.BULAN = dp.BULAN AND h.TAHUN = dp.TAHUN
               ORDER BY h.NAMA_BARANG ASC, h.TAHUN ASC, h.BULAN ASC";
$resultHasil = $connection->query($queryHasil);

$groupedResults = [];
while ($row = $resultHasil->fetch_assoc()) {
    $groupedResults[$row['NAMA_BARANG']][] = $row;
}
?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Owner Dashboard</title>

    <!-- Custom fonts for this template-->
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">

    <!-- Custom styles for this template-->
    <link href="css/sb-admin-2.min.css" rel="stylesheet">

</head>

<body id="page-top">

    <!-- Page Wrapper -->
    <div id="wrapper">

       <!-- Sidebar -->
       <?php include 'sidebar.php'; ?>
        <!-- End of Sidebar -->

        <div class="container">
        <h1 class="my-4"></h1>
        <form method="post" action="">
            <div class="form-group">
                <label for="nama_barang">Nama Barang</label>
                <input list="nama_barang_list" class="form-control" id="nama_barang" name="nama_barang" required>
                <datalist id="nama_barang_list">
                    <?php foreach ($namaBarangList as $namaBarang): ?>
                        <option value="<?php echo htmlspecialchars($namaBarang); ?>">
                    <?php endforeach; ?>
                </datalist>
            </div>
            <div class="form-group">
                <label for="periode">Periode (bulan)</label>
                <select class="form-control" id="periode" name="periode" required>
                    <option value="2">2 Bulan</option>
                    <option value="3">3 Bulan</option>
                    <option value="4">4 Bulan</option>
                    <option value="5">5 Bulan</option>
                </select>
            </div>
            <button type="submit" class="btn btn-primary">Prediksi</button>
        </form>
    </div>
    
        <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->

    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>

    <!-- Logout Modal-->
    <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
        aria-hidden="true">
        <div
        class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
                <div class="modal-footer">
                    <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                    <a class="btn btn-primary" href="logout.php">Logout</a>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap core JavaScript-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Custom scripts for all pages-->
    <script src="js/sb-admin-2.min.js"></script>

</body>

</html>