<?php
session_start();
require_once "koneksi.php"; // File ini berisi kode untuk koneksi ke database

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $NAMA_BARANG = $_POST['NAMA_BARANG'];
    $BULAN = $_POST['BULAN'];
    $TAHUN = $_POST['TAHUN'];
    $JUMLAH_TERJUAL = $_POST['JUMLAH_TERJUAL'];

    // Menggunakan koneksi yang sudah ada
    global $connection;

    // Menghasilkan nilai NOMER baru
    $queryMaxNomer = "SELECT MAX(CAST(NOMER AS UNSIGNED)) AS max_nomer FROM data_penjualan";
    $resultMaxNomer = $connection->query($queryMaxNomer);

    if ($resultMaxNomer && $resultMaxNomer->num_rows > 0) {
        $rowMaxNomer = $resultMaxNomer->fetch_assoc();
        $max_nomer = isset($rowMaxNomer['max_nomer']) ? (int)$rowMaxNomer['max_nomer'] : 0; // Konversi ke integer
        $new_nomer = $max_nomer + 1;
    } else {
        // Jika tidak ada baris yang ditemukan, mulai dari 1
        $new_nomer = 1;
    }

    // Memastikan NOMER memiliki 4 digit dengan padding nol di depan
    $formatted_nomer = str_pad($new_nomer, 4, '0', STR_PAD_LEFT);

    // Memasukkan data ke tabel data_penjualan
    $queryInsert = "INSERT INTO data_penjualan (NOMER, NAMA_BARANG, BULAN, TAHUN, JUMLAH_TERJUAL) VALUES (?, ?, ?, ?, ?)";
    $stmtInsert = $connection->prepare($queryInsert);
    $stmtInsert->bind_param("isiii", $formatted_nomer, $NAMA_BARANG, $BULAN, $TAHUN, $JUMLAH_TERJUAL);

    if ($stmtInsert->execute()) {
        echo "Data penjualan berhasil ditambahkan!";
    } else {
        echo "Error: " . $stmtInsert->error;
    }

    // Menutup statement
    $stmtInsert->close();
}

// Menutup koneksi
$connection->close();
?>
